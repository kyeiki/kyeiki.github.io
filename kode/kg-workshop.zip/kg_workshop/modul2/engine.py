# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Engine varian Modul 2 (drift dari M3/M4 — jangan dicampur).
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler


# --------------------------------------------------------------------------
# 1. Transform3DEngine: Matriks Homogen 4x4 Eksplisit & Hierarki Parent-Child
# --------------------------------------------------------------------------
class Transform3DEngine:
    """
    MATERI 2 - TRANSFORMASI 3D:
    Mengimplementasikan rumus aljabar linear matriks transformasi homogen 4x4:
      M = T(tx, ty, tz) @ Rz(gamma) @ Ry(beta) @ Rx(alpha) @ S(sx, sy, sz) @ Shear
    Semua transformasi objek dihitung dengan perkalian matriks 4x4 sebelum
    diterapkan ke obj.matrix_world atau obj.matrix_local.
    """

    @staticmethod
    def matriks_translasi(tx, ty, tz):
        return Matrix((
            (1.0, 0.0, 0.0, float(tx)),
            (0.0, 1.0, 0.0, float(ty)),
            (0.0, 0.0, 1.0, float(tz)),
            (0.0, 0.0, 0.0, 1.0),
        ))

    @staticmethod
    def matriks_skala(sx, sy, sz):
        return Matrix((
            (float(sx), 0.0,       0.0,       0.0),
            (0.0,       float(sy), 0.0,       0.0),
            (0.0,       0.0,       float(sz), 0.0),
            (0.0,       0.0,       0.0,       1.0),
        ))

    @staticmethod
    def matriks_rotasi_x(rad):
        c, s = math.cos(rad), math.sin(rad)
        return Matrix((
            (1.0, 0.0, 0.0, 0.0),
            (0.0, c,  -s,   0.0),
            (0.0, s,   c,   0.0),
            (0.0, 0.0, 0.0, 1.0),
        ))

    @staticmethod
    def matriks_rotasi_y(rad):
        c, s = math.cos(rad), math.sin(rad)
        return Matrix((
            ( c,  0.0, s,   0.0),
            (0.0, 1.0, 0.0, 0.0),
            (-s,  0.0, c,   0.0),
            (0.0, 0.0, 0.0, 1.0),
        ))

    @staticmethod
    def matriks_rotasi_z(rad):
        c, s = math.cos(rad), math.sin(rad)
        return Matrix((
            (c,  -s,   0.0, 0.0),
            (s,   c,   0.0, 0.0),
            (0.0, 0.0, 1.0, 0.0),
            (0.0, 0.0, 0.0, 1.0),
        ))

    @staticmethod
    def matriks_shear_xy(sh_x=0.0, sh_y=0.0):
        """Matriks Geser (Shearing) pada sumbu X/Y terhadap Z."""
        return Matrix((
            (1.0, 0.0, float(sh_x), 0.0),
            (0.0, 1.0, float(sh_y), 0.0),
            (0.0, 0.0, 1.0,         0.0),
            (0.0, 0.0, 0.0,         1.0),
        ))

    @classmethod
    def komposisi_trs(cls, lokasi=(0.0, 0.0, 0.0), rotasi_euler=(0.0, 0.0, 0.0), skala=(1.0, 1.0, 1.0), shear=(0.0, 0.0)):
        """Menghasilkan matriks komposit M = T @ Rz @ Ry @ Rx @ Shear @ S."""
        T = cls.matriks_translasi(*lokasi)
        Rx = cls.matriks_rotasi_x(rotasi_euler[0])
        Ry = cls.matriks_rotasi_y(rotasi_euler[1])
        Rz = cls.matriks_rotasi_z(rotasi_euler[2])
        Sh = cls.matriks_shear_xy(shear[0], shear[1])
        S = cls.matriks_skala(*skala)
        return T @ Rz @ Ry @ Rx @ Sh @ S

    @classmethod
    def terapkan_matriks(cls, obj, lokasi=(0.0, 0.0, 0.0), rotasi_euler=(0.0, 0.0, 0.0), skala=(1.0, 1.0, 1.0), parent=None):
        """
        Menerapkan matriks transformasi 4x4 ke objek.
        Jika memiliki parent (Hierarki LEGO), maka transformasi dihitung
        relatif terhadap koordinat lokal parent-nya (M_world = M_parent @ M_local).
        """
        M_lokal = cls.komposisi_trs(lokasi, rotasi_euler, skala)
        if parent is not None:
            obj.parent = parent
            obj.matrix_parent_inverse = Matrix.Identity(4)
            obj.matrix_local = M_lokal
        else:
            obj.matrix_world = M_lokal


# --------------------------------------------------------------------------
# 2. SceneManager: Lifecycle Scene & UV Unwrapping Otomatis
# --------------------------------------------------------------------------
class SceneManager:
    @staticmethod
    def bersihkan_scene():
        if bpy.context.active_object and bpy.context.active_object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="SELECT")
        bpy.ops.object.delete()
        for block_list in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.textures, bpy.data.images):
            for item in list(block_list):
                block_list.remove(item)

    @staticmethod
    def buat_koleksi(nama_koleksi):
        if nama_koleksi in bpy.data.collections:
            return bpy.data.collections[nama_koleksi]
        kol = bpy.data.collections.new(nama_koleksi)
        bpy.context.scene.collection.children.link(kol)
        return kol

    @staticmethod
    def pindahkan_ke_koleksi(obj, koleksi):
        for c in list(obj.users_collection):
            c.objects.unlink(obj)
        koleksi.objects.link(obj)

    @staticmethod
    def generate_box_uv(obj):
        """Memastikan mesh memiliki UV Map proporsional (Cube Projection) untuk tekstur."""
        if not obj or obj.type != "MESH":
            return
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        for face in bm.faces:
            n = face.normal
            for loop in face.loops:
                co = loop.vert.co
                if abs(n.z) > 0.5:
                    loop[uv_layer].uv = (co.x, co.y)
                elif abs(n.x) > 0.5:
                    loop[uv_layer].uv = (co.y, co.z)
                else:
                    loop[uv_layer].uv = (co.x, co.z)
        bm.to_mesh(obj.data)
        bm.free()


# --------------------------------------------------------------------------
# 3. TextureMaterialFactory: Procedural Shader Nodes & Image Texture (Materi 2)
# --------------------------------------------------------------------------
class TextureMaterialFactory:
    """
    MATERI 2 - TEXTURE MAPPING & SHADING:
    Membangun jaringan Node Shader di Blender 4.3:
      [TexCoord] -> [Mapping (UV Scale/Rot/Trans)] -> [Procedural/Image Texture]
                                                   -> [Bump Node] -> [Principled BSDF]
    """

    @staticmethod
    def buat_tekstur_citra_checker(nama_img="Tekstur_Lego_Checker", ukuran=256):
        """Membuat Image Texture piksel secara prosedural di memori Blender (tanpa file eksternal)."""
        if nama_img in bpy.data.images:
            return bpy.data.images[nama_img]
        img = bpy.data.images.new(nama_img, width=ukuran, height=ukuran)
        pixels = [0.0] * (ukuran * ukuran * 4)
        for y in range(ukuran):
            for x in range(ukuran):
                idx = (y * ukuran + x) * 4
                kotak = ((x // 32) + (y // 32)) % 2 == 0
                border = (x % 32 < 2) or (y % 32 < 2)
                if border:
                    r, g, b = 0.15, 0.18, 0.22
                elif kotak:
                    r, g, b = 0.92, 0.78, 0.20
                else:
                    r, g, b = 0.18, 0.48, 0.85
                pixels[idx : idx + 4] = [r, g, b, 1.0]
        img.pixels = pixels
        img.pack()
        return img

    @classmethod
    def get_or_create(cls, nama_mat, spec):
        if nama_mat in bpy.data.materials:
            return bpy.data.materials[nama_mat]

        mat = bpy.data.materials.new(name=nama_mat)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        bsdf = nodes.get("Principled BSDF")

        rgba = tuple(spec.get("rgba", [0.8, 0.8, 0.8, 1.0]))
        roughness = float(spec.get("roughness", 0.5))
        metallic = float(spec.get("metallic", 0.0))
        tex_type = spec.get("tex_type", "NONE").upper()
        uv_scale = tuple(spec.get("uv_scale", [4.0, 4.0, 4.0]))
        bump_strength = float(spec.get("bump_strength", 0.1))

        if bsdf:
            bsdf.inputs["Base Color"].default_value = rgba
            bsdf.inputs["Roughness"].default_value = roughness
            if "Metallic" in bsdf.inputs:
                bsdf.inputs["Metallic"].default_value = metallic

            if spec.get("emission") and spec.get("emission_strength", 0) > 0:
                em_in = bsdf.inputs.get("Emission Color") or bsdf.inputs.get("Emission")
                if em_in:
                    em_in.default_value = tuple(spec["emission"])
                if "Emission Strength" in bsdf.inputs:
                    bsdf.inputs["Emission Strength"].default_value = float(spec["emission_strength"])

        if tex_type != "NONE" and bsdf:
            # Buat Node Texture Coordinate & Mapping (Transformasi UV 2D/3D)
            coord_node = nodes.new(type="ShaderNodeTexCoord")
            coord_node.location = (-850, 200)

            map_node = nodes.new(type="ShaderNodeMapping")
            map_node.name = "UV_Mapping"
            map_node.location = (-650, 200)
            map_node.inputs["Scale"].default_value = uv_scale
            links.new(coord_node.outputs["Generated"], map_node.inputs["Vector"])

            bump_node = nodes.new(type="ShaderNodeBump")
            bump_node.location = (-200, -120)
            bump_node.inputs["Strength"].default_value = bump_strength

            if tex_type == "BRICK":
                tex_node = nodes.new(type="ShaderNodeTexBrick")
                tex_node.location = (-420, 200)
                tex_node.inputs["Color1"].default_value = rgba
                tex_node.inputs["Color2"].default_value = tuple(spec.get("color2", [0.6, 0.5, 0.4, 1.0]))
                tex_node.inputs["Mortar"].default_value = (0.35, 0.35, 0.35, 1.0)
                tex_node.inputs["Mortar Size"].default_value = 0.025
                links.new(map_node.outputs["Vector"], tex_node.inputs["Vector"])
                links.new(tex_node.outputs["Color"], bsdf.inputs["Base Color"])
                links.new(tex_node.outputs["Fac"], bump_node.inputs["Height"])
                links.new(bump_node.outputs["Normal"], bsdf.inputs["Normal"])

            elif tex_type == "CHECKER":
                tex_node = nodes.new(type="ShaderNodeTexChecker")
                tex_node.location = (-420, 200)
                tex_node.inputs["Color1"].default_value = rgba
                tex_node.inputs["Color2"].default_value = tuple(spec.get("color2", [0.5, 0.5, 0.5, 1.0]))
                tex_node.inputs["Scale"].default_value = 1.0
                links.new(map_node.outputs["Vector"], tex_node.inputs["Vector"])
                links.new(tex_node.outputs["Color"], bsdf.inputs["Base Color"])
                links.new(tex_node.outputs["Fac"], bump_node.inputs["Height"])
                links.new(bump_node.outputs["Normal"], bsdf.inputs["Normal"])

            elif tex_type == "WOOD":
                tex_node = nodes.new(type="ShaderNodeTexWave")
                tex_node.location = (-450, 200)
                tex_node.wave_type = "BANDS"
                tex_node.inputs["Scale"].default_value = 2.5
                tex_node.inputs["Distortion"].default_value = 4.5
                tex_node.inputs["Detail"].default_value = 3.0

                mix_node = nodes.new(type="ShaderNodeMix")
                mix_node.data_type = "RGBA"
                mix_node.location = (-230, 220)
                mix_node.inputs["A"].default_value = rgba
                mix_node.inputs["B"].default_value = tuple(spec.get("color2", [0.35, 0.20, 0.10, 1.0]))

                links.new(map_node.outputs["Vector"], tex_node.inputs["Vector"])
                links.new(tex_node.outputs["Fac"], mix_node.inputs["Factor"])
                links.new(mix_node.outputs["Result"], bsdf.inputs["Base Color"])
                links.new(tex_node.outputs["Fac"], bump_node.inputs["Height"])
                links.new(bump_node.outputs["Normal"], bsdf.inputs["Normal"])

            elif tex_type in ("NOISE", "LEGO_PLASTIC"):
                tex_node = nodes.new(type="ShaderNodeTexNoise")
                tex_node.location = (-420, 100)
                tex_node.inputs["Scale"].default_value = 25.0 if tex_type == "LEGO_PLASTIC" else 12.0
                tex_node.inputs["Detail"].default_value = 4.0
                bump_node.inputs["Strength"].default_value = 0.03 if tex_type == "LEGO_PLASTIC" else bump_strength
                links.new(map_node.outputs["Vector"], tex_node.inputs["Vector"])
                links.new(tex_node.outputs["Fac"], bump_node.inputs["Height"])
                links.new(bump_node.outputs["Normal"], bsdf.inputs["Normal"])

            elif tex_type == "IMAGE_CHECKER":
                img = cls.buat_tekstur_citra_checker()
                tex_node = nodes.new(type="ShaderNodeTexImage")
                tex_node.location = (-420, 200)
                tex_node.image = img
                links.new(coord_node.outputs["UV"], map_node.inputs["Vector"])
                links.new(map_node.outputs["Vector"], tex_node.inputs["Vector"])
                links.new(tex_node.outputs["Color"], bsdf.inputs["Base Color"])

        mat.diffuse_color = rgba
        return mat


