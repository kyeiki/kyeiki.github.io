# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Transform3DEngine — varian M3=M4 (terverifikasi diff 0 baris).
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler


# --------------------------------------------------------------------------
# 1. Transform3DEngine (Matriks Homogen 4x4 & Hierarki Parent-Child)
# --------------------------------------------------------------------------
class Transform3DEngine:
    @staticmethod
    def komposisi_trs(lokasi=(0.0, 0.0, 0.0), rotasi_euler=(0.0, 0.0, 0.0), skala=(1.0, 1.0, 1.0)):
        T = Matrix.Translation(Vector(lokasi))
        Rx = Matrix.Rotation(rotasi_euler[0], 4, "X")
        Ry = Matrix.Rotation(rotasi_euler[1], 4, "Y")
        Rz = Matrix.Rotation(rotasi_euler[2], 4, "Z")
        S = Matrix.Diagonal((skala[0], skala[1], skala[2], 1.0))
        return T @ Rz @ Ry @ Rx @ S

    @classmethod
    def terapkan_matriks(cls, obj, lokasi=(0.0, 0.0, 0.0), rotasi_euler=(0.0, 0.0, 0.0), skala=(1.0, 1.0, 1.0), parent=None):
        M = cls.komposisi_trs(lokasi, rotasi_euler, skala)
        if parent is not None:
            obj.parent = parent
            obj.matrix_parent_inverse = Matrix.Identity(4)
            obj.matrix_local = M
        else:
            obj.matrix_world = M


