# -*- coding: utf-8 -*-
"""Façade orkestrasi KG Workshop: Modul 1-4 + Capstone.

Badan jalankan_modul_2/3/4 adalah fungsi VERBATIM dari monolith (lihat
modulN/run.py); runner hanya menyatukan pintu masuknya.
"""
from .legacy import modul1_ascii
from .modul2.run import atur_kamera_cahaya_dan_viewport, jalankan_modul_2  # noqa: F401
from .modul3.run import atur_kamera_dan_viewport_makro, jalankan_modul_3  # noqa: F401
from .modul4.run import jalankan_modul_4  # noqa: F401


def jalankan_modul_1():
    """Modul 1: pipeline ASCII -> JSON -> 3D (skrip legacy verbatim `ascii_to_blender_3d.py`)."""
    return modul1_ascii.jalankan_konversi_ascii_ke_3d()


def jalankan_capstone(ascii_makro=None):
    """Capstone: City Tour Kampus Sendiri — basis kota Modul 4 untuk dikustomisasi.

    Tanpa argumen: membangun kota contoh Modul 4 sebagai titik awal.
    Dengan argumen: masterplan ASCII karyamu sendiri (pola ``PETA_MAKRO_ASCII``):

        import kg_workshop.runner as R
        R.jalankan_capstone(ascii_makro=PETA_KAMPUSKU)

    Rancangan lengkap langkah demi langkah: docs/capstone.md (situs workshop).
    """
    from .config.makro import PETA_MAKRO_ASCII
    from .modul4.run import jalankan_modul_4

    return jalankan_modul_4(ascii_makro if ascii_makro is not None else PETA_MAKRO_ASCII)
