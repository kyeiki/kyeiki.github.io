# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# SceneManager varian M4 (purge kamera & action) + LightingRigManager slim M4.
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from ..core34.transform import Transform3DEngine


# --------------------------------------------------------------------------
# 2. SceneManager & Box UV
# --------------------------------------------------------------------------
class SceneManager:
    @staticmethod
    def bersihkan_scene():
        if bpy.context.active_object and bpy.context.active_object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="SELECT")
        bpy.ops.object.delete()
        for block_list in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.lights, bpy.data.cameras, bpy.data.actions):
            for item in list(block_list):
                block_list.remove(item)

    @staticmethod
    def buat_koleksi(nama_koleksi, parent_kol=None):
        if nama_koleksi in bpy.data.collections:
            return bpy.data.collections[nama_koleksi]
        kol = bpy.data.collections.new(nama_koleksi)
        if parent_kol:
            parent_kol.children.link(kol)
        else:
            bpy.context.scene.collection.children.link(kol)
        return kol

    @staticmethod
    def pindahkan_ke_koleksi(obj, koleksi):
        for c in list(obj.users_collection):
            c.objects.unlink(obj)
        koleksi.objects.link(obj)

    @staticmethod
    def generate_box_uv(obj):
        if not obj or obj.type != "MESH":
            return
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        for face in bm.faces:
            n = face.normal
            for loop in face.loops:
                co = loop.vert.co
                if abs(n.z) > 0.5:
                    loop[uv_layer].uv = (co.x, co.y)
                elif abs(n.x) > 0.5:
                    loop[uv_layer].uv = (co.y, co.z)
                else:
                    loop[uv_layer].uv = (co.x, co.z)
        bm.to_mesh(obj.data)
        bm.free()


# --------------------------------------------------------------------------
# 4. LightingRigManager
# --------------------------------------------------------------------------
class LightingRigManager:
    @classmethod
    def bangun_world_dan_lampu(cls, ukuran_kawasan, koleksi_lampu):
        scene = bpy.context.scene
        if not scene.world:
            scene.world = bpy.data.worlds.new("World_Makro_M4")
        world = scene.world
        world.use_nodes = True
        nodes = world.node_tree.nodes
        links = world.node_tree.links
        nodes.clear()

        out_node = nodes.new(type="ShaderNodeOutputWorld")
        bg_node = nodes.new(type="ShaderNodeBackground")
        bg_node.name = "World_BG"
        bg_node.inputs["Color"].default_value = (0.85, 0.42, 0.25, 1.0)
        bg_node.inputs["Strength"].default_value = 0.75
        links.new(bg_node.outputs["Background"], out_node.inputs["Surface"])

        # Compositor Glare (Bloom) untuk efek pendar lampu malam di Blender 4.3
        scene.use_nodes = True
        c_nodes = scene.node_tree.nodes
        c_links = scene.node_tree.links
        c_nodes.clear()
        rl = c_nodes.new(type="CompositorNodeRLayers")
        glare = c_nodes.new(type="CompositorNodeGlare")
        glare.glare_type = "FOG_GLOW"
        glare.quality = "MEDIUM"
        glare.threshold = 1.2
        comp_out = c_nodes.new(type="CompositorNodeComposite")
        c_links.new(rl.outputs["Image"], glare.inputs["Image"])
        c_links.new(glare.outputs["Image"], comp_out.inputs["Image"])

        wx, wy = ukuran_kawasan
        cx, cy = wx / 2.0, wy / 2.0

        light_data = bpy.data.lights.new(name="Sun_MatahariUtama", type="SUN")
        light_data.energy = 2.8
        light_data.color = (1.0, 0.52, 0.22)
        sun_obj = bpy.data.objects.new(name="Sun_MatahariUtama", object_data=light_data)
        bpy.context.scene.collection.objects.link(sun_obj)
        Transform3DEngine.terapkan_matriks(
            sun_obj,
            lokasi=(cx, cy, 35.0),
            rotasi_euler=(math.radians(74), math.radians(12), math.radians(-65)),
        )
        SceneManager.pindahkan_ke_koleksi(sun_obj, koleksi_lampu)


