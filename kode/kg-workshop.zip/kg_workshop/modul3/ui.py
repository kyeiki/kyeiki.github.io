# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Panel MacroLight M3 + registrasinya.
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from ..core34.material import TextureMaterialFactory
from .engine import SceneManager, LightingRigManager
from .builders import MacroAssetBuilder
from ..config.makro import CONFIG_MATERIAL_MODUL3


# ==========================================================================
# BAGIAN 5: APLIKASI INTERAKTIF SIDEBAR UI (TAB 'MacroLight M3')
# ==========================================================================
class MacroLightAppProps(bpy.types.PropertyGroup):
    preset_waktu: bpy.props.EnumProperty(
        name="Suasana Waktu",
        items=[
            ("DAY",    "Siang Hari (Daylight)",        "Matahari terang, lampu PJU mati"),
            ("SUNSET", "Sore / Golden Hour (Sunset)",  "Cahaya jingga hangat, PJU menyala"),
            ("NIGHT",  "Malam Hari (Night City)",      "Langit malam, lampu jalan & gedung bersinar"),
        ],
        default="SUNSET",
    )
    pju_aktif: bpy.props.BoolProperty(name="Nyalakan Lampu Jalan (Spot PJU)", default=True)
    interior_aktif: bpy.props.BoolProperty(name="Nyalakan Lampu Gedung (Point Lt.1 & 2)", default=True)
    sun_elevation: bpy.props.FloatProperty(name="Sudut Elevasi Matahari", default=38.0, min=5.0, max=88.0)
    sun_azimuth: bpy.props.FloatProperty(name="Sudut Putar Matahari (Z)", default=-35.0, min=-180.0, max=180.0)
    spawn_tipe: bpy.props.EnumProperty(
        name="Objek Taman/Jalan",
        items=[
            ("POHON", "Pohon Taman Modular", ""),
            ("PJU",   "Tiang Lampu Jalan (Spot Light)", ""),
            ("MOBIL", "Mobil LEGO Jalan Raya", ""),
        ],
        default="POHON",
    )
    spawn_xy: bpy.props.FloatVectorProperty(name="Posisi XY", default=(32.0, 12.0), size=2)


class MACROLIGHT_OT_apply_lighting(bpy.types.Operator):
    bl_idname = "macrolight.apply_lighting"
    bl_label = "Terapkan Suasana Pencahayaan"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.macrolight_props
        LightingRigManager.terapkan_preset_waktu(
            nama_preset=props.preset_waktu,
            pju_nyala=props.pju_aktif,
            interior_nyala=props.interior_aktif,
        )
        self.report({"INFO"}, f"Mode Pencahayaan '{props.preset_waktu}' berhasil diterapkan!")
        return {"FINISHED"}


class MACROLIGHT_OT_rotate_sun(bpy.types.Operator):
    bl_idname = "macrolight.rotate_sun"
    bl_label = "Putar Arah Bayangan Matahari"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.macrolight_props
        sun = bpy.data.objects.get("Sun_MatahariUtama")
        if sun:
            sun.rotation_euler = (
                math.radians(90.0 - props.sun_elevation),
                math.radians(12.0),
                math.radians(props.sun_azimuth),
            )
        self.report({"INFO"}, "Sudut matahari & arah bayangan diperbarui!")
        return {"FINISHED"}


class MACROLIGHT_OT_spawn_env_object(bpy.types.Operator):
    bl_idname = "macrolight.spawn_env_object"
    bl_label = "Tambah Objek ke Kawasan"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.macrolight_props
        kol_utama = SceneManager.buat_koleksi("KawasanMakro_Modul3")
        kol_lampu = SceneManager.buat_koleksi("LightingRig_Modul3", kol_utama)
        builder = MacroAssetBuilder(TextureMaterialFactory(), CONFIG_MATERIAL_MODUL3, kol_utama, kol_lampu)
        xy = [props.spawn_xy[0], props.spawn_xy[1]]
        idx = len(bpy.data.objects) + 1
        if props.spawn_tipe == "POHON":
            obj = builder.bangun_pohon_modular(idx, xy)
        elif props.spawn_tipe == "PJU":
            obj = builder.bangun_lampu_jalan_pju(idx, xy, 1.0)
        else:
            obj = builder.bangun_mobil_lego(idx, xy)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        self.report({"INFO"}, f"{obj.name} ditambahkan di ({xy[0]:.1f}, {xy[1]:.1f})")
        return {"FINISHED"}


class MACROLIGHT_PT_main_panel(bpy.types.Panel):
    bl_label = "Modul 3: Lighting & Kawasan Makro"
    bl_idname = "MACROLIGHT_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "MacroLight M3"

    def draw(self, context):
        layout = self.layout
        props = context.scene.macrolight_props

        box1 = layout.box()
        box1.label(text="1. Simulasi Waktu & Environment", icon="WORLD")
        box1.prop(props, "preset_waktu")
        box1.prop(props, "pju_aktif")
        box1.prop(props, "interior_aktif")
        box1.operator("macrolight.apply_lighting", icon="LIGHT_SUN")

        box2 = layout.box()
        box2.label(text="2. Arah Directional Light (Matahari)", icon="ORIENTATION_GIMBAL")
        box2.prop(props, "sun_elevation")
        box2.prop(props, "sun_azimuth")
        box2.operator("macrolight.rotate_sun", icon="FILE_REFRESH")

        box3 = layout.box()
        box3.label(text="3. Tambah Objek Taman & Jalan", icon="SCENE_DATA")
        box3.prop(props, "spawn_tipe")
        box3.prop(props, "spawn_xy")
        box3.operator("macrolight.spawn_env_object", icon="ADD")


KELAS_UI_MODUL3 = (
    MacroLightAppProps,
    MACROLIGHT_OT_apply_lighting,
    MACROLIGHT_OT_rotate_sun,
    MACROLIGHT_OT_spawn_env_object,
    MACROLIGHT_PT_main_panel,
)


def register_modul3_ui():
    for cls in KELAS_UI_MODUL3:
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        bpy.utils.register_class(cls)
    bpy.types.Scene.macrolight_props = bpy.props.PointerProperty(type=MacroLightAppProps)


