# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Orkestrasi Modul 2 (badan fungsi verbatim dari monolith).
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from ..config.denah import (DENAH_ASCII, DEFAULT_CONFIG_ASSETS, SKALA_X_METER_PER_KARAKTER,
    SKALA_Y_METER_PER_KARAKTER, TEBAL_DINDING_DEFAULT, TINGGI_DINDING_DEFAULT)
from .parser import AsciiDenahParser
from .engine import SceneManager, TextureMaterialFactory
from .builders import AssetBuilder, DenahBuilder
from .ui import register_lego_ui

BLENDER_AVAILABLE = True


# ==============================================================================
# BAGIAN 6: ORKESTRASI UTAMA & PENCAHAYAAN PRATINJAU MATERIAL
# ==============================================================================
def atur_kamera_cahaya_dan_viewport(grid_xy):
    if not BLENDER_AVAILABLE:
        return
    gx, gy = float(grid_xy[0]), float(grid_xy[1])
    cx, cy = gx / 2.0, gy / 2.0

    bpy.ops.object.light_add(type="SUN", location=(cx + 10.0, cy - 12.0, 25.0))
    sun = bpy.context.active_object
    sun.name = "Matahari_Modul2"
    sun.data.energy = 4.0
    sun.rotation_euler = (math.radians(38), math.radians(18), math.radians(-25))

    bpy.ops.object.camera_add(location=(cx, -gy * 0.65, max(gx, gy) * 0.95))
    cam = bpy.context.active_object
    cam.name = "Kamera_Modul2"
    cam.rotation_euler = (math.radians(46), 0.0, 0.0)
    cam.data.lens = 32.0
    bpy.context.scene.camera = cam

    # Otomatis aktifkan mode shading 'MATERIAL' agar tekstur langsung terlihat
    for area in bpy.context.screen.areas:
        if area.type == "VIEW_3D":
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    space.shading.type = "MATERIAL"


def jalankan_modul_2(ascii_str=DENAH_ASCII):
    parser = AsciiDenahParser(
        scale_x=SKALA_X_METER_PER_KARAKTER,
        scale_y=SKALA_Y_METER_PER_KARAKTER,
        tinggi_dinding=TINGGI_DINDING_DEFAULT,
        tebal_dinding=TEBAL_DINDING_DEFAULT,
    )
    cfg_denah = parser.parse_to_dict(ascii_str)
    cfg_assets = DEFAULT_CONFIG_ASSETS

    if BLENDER_AVAILABLE:
        SceneManager.bersihkan_scene()
        koleksi = SceneManager.buat_koleksi("RumahLego_Modul2")
        builder = AssetBuilder(TextureMaterialFactory(), cfg_assets["palet"])
        DenahBuilder(builder, cfg_denah["rumah"]).bangun_semua()

        for obj in list(bpy.context.scene.objects):
            SceneManager.pindahkan_ke_koleksi(obj, koleksi)

        atur_kamera_cahaya_dan_viewport(cfg_denah["rumah"]["grid"])
        register_lego_ui()
        print("MATERI 2 OK: Transformasi Matriks 4x4, Tekstur Prosedural, & Panel UI 'LegoApp M2' aktif!")

    return cfg_denah


