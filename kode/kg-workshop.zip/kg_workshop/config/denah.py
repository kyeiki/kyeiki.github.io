# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Konfigurasi denah & material Modul 2 (sumber: modul2.py BAGIAN 1-2).

# ==============================================================================
# BAGIAN 1: KONFIGURASI DENAH ASCII & PARAMETER SKALA
# ==============================================================================
SKALA_X_METER_PER_KARAKTER = 0.5
SKALA_Y_METER_PER_KARAKTER = 0.5
TINGGI_DINDING_DEFAULT     = 3.0
TEBAL_DINDING_DEFAULT      = 0.15

DENAH_ASCII = r"""
+---+---------------------------------------------------------+---+
|   | [R] | [R] | [R] |     |     |     | [R] | [R] | [R] | [R] |   |
|   +-----+-----+-----+     |     |     +-----+-----+-----+-----+   |
|   |                 |                                   |     |   |
| R |                                                           | R |
| . |                    WORK STATION (UTARA)                   | . |
| A |                                                           | A |
| R |                                                           | R |
| S |                                                           | S |
| I |                                                           | I |
| P |                                                           | P |
+---+-------+-------------------+-----+-------------------+-----+---+
|   |       |    TOILET PRIA    |     |  LIFT  |  PANTRY  |     |   |
|   |       +-------------------+     +--------+----------+     |   |
|   |       | R.AHU | [LIFT-1]  |  C  |  LIFT  |  TANGGA  |     |   |
|   |       |       | [LIFT-2]  |  O  +--------+ DARURAT  |     |   |
|   |       +-------+-----------+  R  | [LIFT] |          |     |   |
|   |       |                   |  I  +--------+----------+     |   |
|   |       |   TOILET WANITA   |  D  |    TANGGA DARURAT |     |   |
|   |       |                   |  O  +-------------------+     |   |
|   |       |                   |  R  |      R. PANEL     |     |   |
+---+-------+-------------------+-----+-------------------+-----+---+
|   |                                                           |   |
| R |                                                           | R |
| . |                    WORK STATION (SELATAN)                 | . |
| A |                                                           | A |
| R |                                                           | R |
| S |                                                           | S |
| I |                                                           | I |
| P |                 |                                   |     | P |
|   +---+---+---+-----+---+---+---+---+---+---+---+---+---+-----+   |
|   | R | R | R |  R  | R | R | R | R | R | R | R | R | R |  R  |   |
+---+---+---+---+-----+---+---+---+---+---+---+---+---+---+-----+---+
"""


# ==============================================================================
# BAGIAN 2: PALET MATERIAL & KONFIGURASI TEKSTUR PROSEDURAL (MATERI 2)
# Mendukung tipe tekstur: "NONE", "BRICK", "CHECKER", "WOOD", "NOISE", "LEGO_PLASTIC"
# ==============================================================================
DEFAULT_CONFIG_ASSETS = {
    "palet": {
        "dinding_eksterior": {
            "rgba": [0.88, 0.84, 0.78, 1.0], "roughness": 0.85,
            "tex_type": "BRICK", "color2": [0.65, 0.58, 0.50, 1.0],
            "uv_scale": [4.0, 4.0, 4.0], "bump_strength": 0.25
        },
        "dinding_interior": {
            "rgba": [0.90, 0.91, 0.93, 1.0], "roughness": 0.75,
            "tex_type": "NOISE", "uv_scale": [8.0, 8.0, 8.0], "bump_strength": 0.08
        },
        "dinding_core": {
            "rgba": [0.72, 0.76, 0.80, 1.0], "roughness": 0.65,
            "tex_type": "BRICK", "color2": [0.55, 0.58, 0.62, 1.0],
            "uv_scale": [3.0, 3.0, 3.0], "bump_strength": 0.20
        },
        "kusen_kayu": {
            "rgba": [0.42, 0.25, 0.12, 1.0], "roughness": 0.55,
            "tex_type": "WOOD", "color2": [0.25, 0.14, 0.06, 1.0],
            "uv_scale": [6.0, 6.0, 6.0], "bump_strength": 0.12
        },
        "kusen_aluminium": {"rgba": [0.22, 0.25, 0.28, 1.0], "roughness": 0.25, "metallic": 0.8},
        "kaca_jendela": {
            "rgba": [0.65, 0.85, 0.95, 1.0], "roughness": 0.10,
            "emission": [0.4, 0.6, 0.7, 1.0], "emission_strength": 0.20
        },
        "lantai_workstation": {
            "rgba": [0.85, 0.82, 0.75, 1.0], "roughness": 0.45,
            "tex_type": "CHECKER", "color2": [0.72, 0.68, 0.60, 1.0],
            "uv_scale": [12.0, 12.0, 1.0], "bump_strength": 0.05
        },
        "lantai_koridor": {
            "rgba": [0.78, 0.80, 0.83, 1.0], "roughness": 0.35,
            "tex_type": "CHECKER", "color2": [0.60, 0.63, 0.68, 1.0],
            "uv_scale": [8.0, 8.0, 1.0], "bump_strength": 0.05
        },
        "lantai_ruang_r": {
            "rgba": [0.68, 0.48, 0.30, 1.0], "roughness": 0.50,
            "tex_type": "WOOD", "color2": [0.48, 0.32, 0.18, 1.0],
            "uv_scale": [5.0, 5.0, 5.0], "bump_strength": 0.10
        },
        "lantai_arsip": {
            "rgba": [0.58, 0.60, 0.62, 1.0], "roughness": 0.80,
            "tex_type": "NOISE", "uv_scale": [10.0, 10.0, 1.0], "bump_strength": 0.15
        },
        "lantai_toilet": {
            "rgba": [0.82, 0.94, 0.96, 1.0], "roughness": 0.25,
            "tex_type": "CHECKER", "color2": [0.62, 0.82, 0.86, 1.0],
            "uv_scale": [16.0, 16.0, 1.0], "bump_strength": 0.08
        },
        "lantai_pantry": {
            "rgba": [0.90, 0.84, 0.72, 1.0], "roughness": 0.40,
            "tex_type": "CHECKER", "color2": [0.76, 0.66, 0.52, 1.0],
            "uv_scale": [10.0, 10.0, 1.0], "bump_strength": 0.06
        },
        "lantai_teknis": {"rgba": [0.42, 0.45, 0.48, 1.0], "roughness": 0.85, "tex_type": "NOISE"},
        "lantai_tangga": {"rgba": [0.52, 0.50, 0.48, 1.0], "roughness": 0.80},
        "lantai_lift":   {"rgba": [0.30, 0.32, 0.35, 1.0], "roughness": 0.35, "metallic": 0.6},
        "kayu_meja": {
            "rgba": [0.76, 0.55, 0.34, 1.0], "roughness": 0.45,
            "tex_type": "WOOD", "color2": [0.55, 0.38, 0.20, 1.0],
            "uv_scale": [4.0, 4.0, 4.0], "bump_strength": 0.08
        },
        "kayu_gelap": {
            "rgba": [0.32, 0.20, 0.11, 1.0], "roughness": 0.50,
            "tex_type": "WOOD", "color2": [0.18, 0.10, 0.05, 1.0],
            "uv_scale": [5.0, 5.0, 5.0], "bump_strength": 0.10
        },
        "partisi_kubikel": {"rgba": [0.46, 0.56, 0.68, 1.0], "roughness": 0.80, "tex_type": "NOISE"},
        "kursi_kantor":    {"rgba": [0.18, 0.20, 0.24, 1.0], "roughness": 0.65},
        "kain_sofa":       {"rgba": [0.26, 0.42, 0.58, 1.0], "roughness": 0.85, "tex_type": "NOISE"},
        "kain_kasur":      {"rgba": [0.92, 0.90, 0.86, 1.0], "roughness": 0.80},
        "selimut_biru":    {"rgba": [0.30, 0.50, 0.72, 1.0], "roughness": 0.85},
        "logam_abu":       {"rgba": [0.65, 0.68, 0.72, 1.0], "roughness": 0.30, "metallic": 0.75},
        "logam_lift":      {"rgba": [0.80, 0.82, 0.85, 1.0], "roughness": 0.20, "metallic": 0.85},
        "keramik_putih":   {"rgba": [0.96, 0.97, 0.98, 1.0], "roughness": 0.15},
        "layar_monitor": {
            "rgba": [0.08, 0.12, 0.18, 1.0], "roughness": 0.15,
            "emission": [0.15, 0.50, 0.95, 1.0], "emission_strength": 0.8
        },
        "hijau_daun":      {"rgba": [0.22, 0.58, 0.26, 1.0], "roughness": 0.65},
        "pot_terakota":    {"rgba": [0.72, 0.38, 0.22, 1.0], "roughness": 0.75, "tex_type": "NOISE"},
        "panel_listrik":   {"rgba": [0.25, 0.32, 0.38, 1.0], "roughness": 0.45, "metallic": 0.5},
        "lampu_indikator": {
            "rgba": [0.10, 0.90, 0.30, 1.0], "roughness": 0.20,
            "emission": [0.10, 0.95, 0.30, 1.0], "emission_strength": 2.5
        },
        "mesin_hvac":      {"rgba": [0.35, 0.52, 0.65, 1.0], "roughness": 0.40, "metallic": 0.5},
        "kardus_arsip":    {"rgba": [0.78, 0.64, 0.44, 1.0], "roughness": 0.85},
        "rail_tangga":     {"rgba": [0.85, 0.22, 0.18, 1.0], "roughness": 0.35},
        "teks_label":      {"rgba": [0.12, 0.14, 0.18, 1.0], "roughness": 0.50},
        # Material Khusus Balok LEGO (Materi 2)
        "lego_merah":      {"rgba": [0.85, 0.12, 0.12, 1.0], "roughness": 0.20, "tex_type": "LEGO_PLASTIC"},
        "lego_kuning":     {"rgba": [0.95, 0.78, 0.08, 1.0], "roughness": 0.20, "tex_type": "LEGO_PLASTIC"},
        "lego_biru":       {"rgba": [0.10, 0.38, 0.82, 1.0], "roughness": 0.20, "tex_type": "LEGO_PLASTIC"},
        "lego_hijau":      {"rgba": [0.12, 0.68, 0.28, 1.0], "roughness": 0.20, "tex_type": "LEGO_PLASTIC"}
    }
}


