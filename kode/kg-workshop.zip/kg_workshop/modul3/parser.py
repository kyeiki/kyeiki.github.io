# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# AsciiMacroParser — varian Modul 3.
import json
import math
import re
from collections import deque


# ==============================================================================
# BAGIAN 3: PARSER KAWASAN MAKRO ASCII (Mendukung 3 Gedung + Jalan + Taman)
# ==============================================================================
class AsciiMacroParser:
    """
    Mengekstrak:
      1. Footprint kotak gedung (GEDUNG A, GEDUNG B, GEDUNG C) via Flood-Fill
      2. Jalur jalan raya, marka jalan, trotoar, dan hamparan rumput
      3. Titik koordinat objek taman: Pohon ('T'), Lampu Jalan ('L'),
         Bangku ('B'), Air Mancur ('W'), dan Mobil LEGO ('C')
    """

    def __init__(self, scale=1.0):
        self.scale = float(scale)

    @staticmethod
    def _normalisasi_grid(ascii_text):
        lines = [l.rstrip("\r\n") for l in ascii_text.strip().splitlines() if l.strip()]
        max_w = max(len(l) for l in lines)
        return [l.ljust(max_w) for l in lines]

    def _rc_to_xy(self, r, c, max_r):
        return round(c * self.scale, 2), round((max_r - r) * self.scale, 2)

    def parse(self, ascii_text):
        grid = self._normalisasi_grid(ascii_text)
        H, W = len(grid), len(grid[0])
        max_r = H - 1

        # 1. Ekstrak kotak gedung yang dibatasi '+', '-', '|'
        visited = [[False] * W for _ in range(H)]
        buildings = []
        building_cells = set()

        for r in range(H):
            for c in range(W):
                if grid[r][c] == "+" and not visited[r][c]:
                    # Cari batas kanan dan bawah kotak gedung
                    c2 = c + 1
                    while c2 < W and grid[r][c2] == "-":
                        c2 += 1
                    if c2 < W and grid[r][c2] == "+":
                        r2 = r + 1
                        while r2 < H and grid[r2][c] == "|":
                            r2 += 1
                        if r2 < H and grid[r2][c] == "+":
                            # Tandai seluruh sel di dalam kotak gedung
                            teks_dalam = []
                            for rr in range(r, r2 + 1):
                                row_str = ""
                                for cc in range(c, c2 + 1):
                                    visited[rr][cc] = True
                                    building_cells.add((rr, cc))
                                    if r < rr < r2 and c < cc < c2:
                                        row_str += grid[rr][cc]
                                if row_str.strip():
                                    teks_dalam.append(" ".join(row_str.split()))

                            label_gabung = " ".join(teks_dalam)
                            nama_gedung = f"Gedung_{len(buildings)+1}"
                            if "GEDUNG A" in label_gabung.upper():
                                nama_gedung = "Gedung_A_KantorUtama"
                            elif "GEDUNG B" in label_gabung.upper():
                                nama_gedung = "Gedung_B_PusatRiset"
                            elif "GEDUNG C" in label_gabung.upper():
                                nama_gedung = "Gedung_C_Convention"

                            x1, y2 = self._rc_to_xy(r, c, max_r)
                            x2, y1 = self._rc_to_xy(r2, c2, max_r)
                            buildings.append({
                                "id": len(buildings),
                                "nama": nama_gedung,
                                "label": label_gabung,
                                "min_xy": [min(x1, x2), min(y1, y2)],
                                "max_xy": [max(x1, x2), max(y1, y2)],
                                "jumlah_lantai": 2,
                            })

        # 2. Ekstrak baris zona jalan & trotoar serta objek titik (T, L, B, W, C, #)
        pohon_list, lampu_jalan_list, bangku_list, kolam_cells, mobil_list, marka_list = [], [], [], [], [], []
        jalan_rows, trotoar_rows = set(), set()

        for r in range(H):
            for c in range(W):
                if (r, c) in building_cells:
                    continue
                ch = grid[r][c]
                x, y = self._rc_to_xy(r, c, max_r)
                if ch == "=":
                    jalan_rows.add(r)
                elif ch == "#":
                    jalan_rows.add(r)
                    marka_list.append([x, y])
                elif ch == ".":
                    trotoar_rows.add(r)
                elif ch == "T":
                    pohon_list.append([x, y])
                elif ch == "L":
                    trotoar_rows.add(r)
                    lampu_jalan_list.append([x, y])
                elif ch == "B":
                    bangku_list.append([x, y])
                elif ch == "W":
                    kolam_cells.append([x, y])
                elif ch == "C":
                    jalan_rows.add(r)
                    mobil_list.append([x, y])

        lebar_kawasan = round((W - 1) * self.scale, 2)
        tinggi_kawasan = round((H - 1) * self.scale, 2)

        # Rentang Y jalan raya & trotoar
        if jalan_rows:
            _, y_j_max = self._rc_to_xy(min(jalan_rows), 0, max_r)
            _, y_j_min = self._rc_to_xy(max(jalan_rows), 0, max_r)
            zona_jalan = [min(y_j_min, y_j_max) - 0.5, max(y_j_min, y_j_max) + 0.5]
        else:
            zona_jalan = [tinggi_kawasan * 0.4, tinggi_kawasan * 0.6]

        return {
            "ukuran_kawasan": [lebar_kawasan, tinggi_kawasan],
            "zona_jalan_y": zona_jalan,
            "gedung": buildings,
            "pohon": pohon_list,
            "lampu_jalan": lampu_jalan_list,
            "bangku": bangku_list,
            "kolam_cells": kolam_cells,
            "mobil": mobil_list,
            "marka": marka_list,
        }


