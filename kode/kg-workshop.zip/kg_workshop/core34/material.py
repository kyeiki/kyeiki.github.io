# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# TextureMaterialFactory — varian M3=M4 (terverifikasi diff 0 baris).
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler


# --------------------------------------------------------------------------
# 3. TextureMaterialFactory
# --------------------------------------------------------------------------
class TextureMaterialFactory:
    @classmethod
    def get_or_create(cls, nama_mat, spec):
        if nama_mat in bpy.data.materials:
            return bpy.data.materials[nama_mat]

        mat = bpy.data.materials.new(name=nama_mat)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        bsdf = nodes.get("Principled BSDF")

        rgba = tuple(spec.get("rgba", [0.8, 0.8, 0.8, 1.0]))
        tex_type = spec.get("tex_type", "NONE").upper()
        uv_scale = tuple(spec.get("uv_scale", [4.0, 4.0, 4.0]))
        bump_val = float(spec.get("bump", 0.1))

        if bsdf:
            bsdf.inputs["Base Color"].default_value = rgba
            bsdf.inputs["Roughness"].default_value = float(spec.get("roughness", 0.5))
            if "Metallic" in bsdf.inputs:
                bsdf.inputs["Metallic"].default_value = float(spec.get("metallic", 0.0))
            if spec.get("emission"):
                em_in = bsdf.inputs.get("Emission Color") or bsdf.inputs.get("Emission")
                if em_in:
                    em_in.default_value = tuple(spec["emission"])
                if "Emission Strength" in bsdf.inputs:
                    bsdf.inputs["Emission Strength"].default_value = float(spec.get("emission_strength", 1.0))

        if tex_type != "NONE" and bsdf:
            coord = nodes.new(type="ShaderNodeTexCoord")
            mapping = nodes.new(type="ShaderNodeMapping")
            mapping.inputs["Scale"].default_value = uv_scale
            links.new(coord.outputs["Generated"], mapping.inputs["Vector"])

            bump = nodes.new(type="ShaderNodeBump")
            bump.inputs["Strength"].default_value = bump_val

            if tex_type == "BRICK":
                tex = nodes.new(type="ShaderNodeTexBrick")
                tex.inputs["Color1"].default_value = rgba
                tex.inputs["Color2"].default_value = tuple(spec.get("color2", [0.6, 0.5, 0.4, 1.0]))
                tex.inputs["Mortar Size"].default_value = 0.02
                links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
                links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
                links.new(tex.outputs["Fac"], bump.inputs["Height"])
                links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

            elif tex_type == "CHECKER":
                tex = nodes.new(type="ShaderNodeTexChecker")
                tex.inputs["Color1"].default_value = rgba
                tex.inputs["Color2"].default_value = tuple(spec.get("color2", [0.5, 0.5, 0.5, 1.0]))
                links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
                links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
                links.new(tex.outputs["Fac"], bump.inputs["Height"])
                links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

            elif tex_type == "WOOD":
                tex = nodes.new(type="ShaderNodeTexWave")
                tex.inputs["Scale"].default_value = 3.0
                tex.inputs["Distortion"].default_value = 4.0
                mix = nodes.new(type="ShaderNodeMix")
                mix.data_type = "RGBA"
                mix.inputs["A"].default_value = rgba
                mix.inputs["B"].default_value = tuple(spec.get("color2", [0.3, 0.2, 0.1, 1.0]))
                links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
                links.new(tex.outputs["Fac"], mix.inputs["Factor"])
                links.new(mix.outputs["Result"], bsdf.inputs["Base Color"])
                links.new(tex.outputs["Fac"], bump.inputs["Height"])
                links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

            elif tex_type == "NOISE":
                tex = nodes.new(type="ShaderNodeTexNoise")
                tex.inputs["Scale"].default_value = 15.0
                links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
                links.new(tex.outputs["Fac"], bump.inputs["Height"])
                links.new(bump.outputs["Normal"], bsdf.inputs["Normal"])

        mat.diffuse_color = rgba
        return mat


