# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Panel LegoApp M2 + registrasinya.
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from .engine import SceneManager, Transform3DEngine, TextureMaterialFactory
from .builders import AssetBuilder
from ..config.denah import DEFAULT_CONFIG_ASSETS


# ==========================================================================
# BAGIAN 5: LEGO BUILDER & 3D TRANSFORM INTERACTIVE APP (SIDEBAR N-PANEL)
# Menjadikan script ini seperti Aplikasi di dalam Blender!
# ==========================================================================
class LegoTransformAppProps(bpy.types.PropertyGroup):
    brick_color: bpy.props.EnumProperty(
        name="Warna LEGO",
        items=[
            ("lego_merah",  "Merah LEGO",  ""),
            ("lego_kuning", "Kuning LEGO", ""),
            ("lego_biru",   "Biru LEGO",   ""),
            ("lego_hijau",  "Hijau LEGO",  ""),
        ],
        default="lego_merah",
    )
    studs_x: bpy.props.IntProperty(name="Stud X", default=2, min=1, max=8)
    studs_y: bpy.props.IntProperty(name="Stud Y", default=4, min=1, max=8)

    # Parameter Transformasi Matriks 3D
    trans_xyz: bpy.props.FloatVectorProperty(name="Translasi (T)", default=(18.0, 9.0, 0.0), subtype="TRANSLATION")
    rot_deg: bpy.props.FloatVectorProperty(name="Rotasi Euler (deg)", default=(0.0, 0.0, 0.0), subtype="XYZ")
    scale_xyz: bpy.props.FloatVectorProperty(name="Skala (S)", default=(1.0, 1.0, 1.0), min=0.1, max=10.0, subtype="XYZ")
    shear_xy: bpy.props.FloatVectorProperty(name="Shear XY", default=(0.0, 0.0), size=2, min=-1.5, max=1.5)

    # Parameter Texture & UV Mapping
    preset_tekstur: bpy.props.EnumProperty(
        name="Preset Tekstur",
        items=[
            ("BRICK",         "Bata Prosedural (Brick + Bump)", ""),
            ("CHECKER",       "Ubin Catur (Checker)",           ""),
            ("WOOD",          "Serat Kayu (Wave Wood)",         ""),
            ("IMAGE_CHECKER", "Image Texture (UV Pixel Map)",   ""),
            ("LEGO_PLASTIC",  "Plastik LEGO Glossy",            ""),
        ],
        default="BRICK",
    )
    uv_scale_val: bpy.props.FloatProperty(name="Skala UV", default=4.0, min=0.2, max=30.0)


class LEGOAPP_OT_spawn_brick(bpy.types.Operator):
    bl_idname = "legoapp.spawn_brick"
    bl_label = "Tambah Balok LEGO (Matriks 4x4)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.lego_app_props
        builder = AssetBuilder(TextureMaterialFactory(), DEFAULT_CONFIG_ASSETS["palet"])
        rot_rad = [math.radians(a) for a in props.rot_deg]
        brick = builder.membangun({
            "type": "lego_brick",
            "nama": f"Lego_{props.studs_x}x{props.studs_y}",
            "studs_x": props.studs_x,
            "studs_y": props.studs_y,
            "unit_size": 0.35,
            "height": 0.40,
            "di": [props.trans_xyz[0], props.trans_xyz[1]],
            "z": props.trans_xyz[2],
            "rot": rot_rad,
            "scale": list(props.scale_xyz),
            "material": props.brick_color,
        })
        context.view_layer.objects.active = brick
        brick.select_set(True)
        self.report({"INFO"}, f"Balok LEGO {brick.name} berhasil dirakit!")
        return {"FINISHED"}


class LEGOAPP_OT_apply_matrix(bpy.types.Operator):
    bl_idname = "legoapp.apply_matrix"
    bl_label = "Terapkan Matriks 4x4 ke Objek Aktif"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({"WARNING"}, "Pilih objek terlebih dahulu di 3D Viewport!")
            return {"CANCELLED"}
        props = context.scene.lego_app_props
        rot_rad = [math.radians(a) for a in props.rot_deg]
        M = Transform3DEngine.komposisi_trs(
            lokasi=tuple(props.trans_xyz),
            rotasi_euler=rot_rad,
            skala=tuple(props.scale_xyz),
            shear=tuple(props.shear_xy),
        )
        obj.matrix_world = M
        self.report({"INFO"}, f"Matriks 4x4 (T*R*Shear*S) diterapkan ke {obj.name}")
        return {"FINISHED"}


class LEGOAPP_OT_apply_texture(bpy.types.Operator):
    bl_idname = "legoapp.apply_texture"
    bl_label = "Terapkan Tekstur & Skala UV"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != "MESH":
            self.report({"WARNING"}, "Pilih objek MESH (Lantai/Dinding/Bata) terlebih dahulu!")
            return {"CANCELLED"}
        props = context.scene.lego_app_props
        s = props.uv_scale_val
        nama_mat = f"Mat_Custom_{props.preset_tekstur}_{int(s*10)}"
        spec = {
            "rgba": [0.85, 0.78, 0.68, 1.0],
            "color2": [0.35, 0.28, 0.22, 1.0],
            "roughness": 0.35,
            "tex_type": props.preset_tekstur,
            "uv_scale": [s, s, s],
            "bump_strength": 0.20,
        }
        if nama_mat in bpy.data.materials:
            bpy.data.materials.remove(bpy.data.materials[nama_mat])
        mat = TextureMaterialFactory.get_or_create(nama_mat, spec)
        SceneManager.generate_box_uv(obj)
        obj.data.materials.clear()
        obj.data.materials.append(mat)
        self.report({"INFO"}, f"Tekstur {props.preset_tekstur} (UV Scale={s:.1f}) diterapkan ke {obj.name}")
        return {"FINISHED"}


class LEGOAPP_PT_main_panel(bpy.types.Panel):
    bl_label = "Modul 2: LEGO 3D Transform & Texture"
    bl_idname = "LEGOAPP_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "LegoApp M2"

    def draw(self, context):
        layout = self.layout
        props = context.scene.lego_app_props

        box1 = layout.box()
        box1.label(text="1. Generator Balok LEGO Modular", icon="MESH_CUBE")
        box1.prop(props, "brick_color")
        row = box1.row(align=True)
        row.prop(props, "studs_x")
        row.prop(props, "studs_y")
        box1.operator("legoapp.spawn_brick", icon="ADD")

        box2 = layout.box()
        box2.label(text="2. Matriks Transformasi 3D (4x4)", icon="ORIENTATION_GLOBAL")
        box2.prop(props, "trans_xyz")
        box2.prop(props, "rot_deg")
        box2.prop(props, "scale_xyz")
        box2.prop(props, "shear_xy")
        box2.operator("legoapp.apply_matrix", icon="CHECKMARK")

        box3 = layout.box()
        box3.label(text="3. Shader Texture & UV Mapping", icon="MATERIAL")
        box3.prop(props, "preset_tekstur")
        box3.prop(props, "uv_scale_val")
        box3.operator("legoapp.apply_texture", icon="TEXTURE")


DAFTAR_KELAS_UI = (
    LegoTransformAppProps,
    LEGOAPP_OT_spawn_brick,
    LEGOAPP_OT_apply_matrix,
    LEGOAPP_OT_apply_texture,
    LEGOAPP_PT_main_panel,
)


def register_lego_ui():
    for cls in DAFTAR_KELAS_UI:
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        bpy.utils.register_class(cls)
    bpy.types.Scene.lego_app_props = bpy.props.PointerProperty(type=LegoTransformAppProps)


