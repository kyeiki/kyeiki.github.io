# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Panel CityTour M4 + registrasinya.
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from .anim import KeyframeAnimator, ExportPipelineManager
from ..config.animasi import TOTAL_FRAMES


# ==========================================================================
# BAGIAN 4: APLIKASI INTERAKTIF SIDEBAR UI (TAB 'CityTour M4')
# ==========================================================================
class CityTourAppProps(bpy.types.PropertyGroup):
    kamera_aktif: bpy.props.EnumProperty(
        name="Pilih Kamera",
        items=[
            ("Cam_Drone_Orbit",     "1. Drone Flythrough (Spline Path)", "Tur udara mengelilingi 3 gedung"),
            ("Cam_Street_EyeLevel", "2. Eye-Level Pejalan Kaki (DoF)",   "Perspektif 35mm sejajar mata"),
            ("Cam_Isometric_Ortho", "3. Isometrik Ortografis (Blueprint)","Proyeksi paralel tanpa distorsi"),
            ("Cam_Car_Dashcam",     "4. Dashcam Mobil LEGO (Hierarki)",   "Ikut bergerak bersama mobil"),
        ],
        default="Cam_Drone_Orbit",
    )
    tipe_proyeksi: bpy.props.EnumProperty(
        name="Tipe Proyeksi",
        items=[
            ("PERSP", "Perspektif (Titik Hilang)", ""),
            ("ORTHO", "Ortografis (Paralel)", ""),
        ],
        default="PERSP",
    )
    focal_length: bpy.props.FloatProperty(name="Focal Length (mm)", default=24.0, min=12.0, max=120.0)
    aktif_dof: bpy.props.BoolProperty(name="Depth of Field (Bokeh Malam)", default=True)
    aperture_fstop: bpy.props.FloatProperty(name="Aperture (f-stop)", default=2.0, min=0.8, max=16.0)

    # Properti Render MP4 & Ekspor Web 3D (.GLB)
    output_dir: bpy.props.StringProperty(
        name="Folder Output",
        description="Kosongkan untuk menyimpan otomatis ke Desktop / folder file .blend",
        default="",
        subtype="DIR_PATH",
    )
    render_res: bpy.props.EnumProperty(
        name="Resolusi MP4",
        items=[
            ("720P",  "720p HD (1280x720 - Cepat)",      "Cocok untuk uji coba praktikum"),
            ("1080P", "1080p Full HD (1920x1080 - Tajam)","Cocok untuk presentasi final"),
        ],
        default="720P",
    )
    glb_include_anim: bpy.props.BoolProperty(
        name="Sertakan Animasi & Kamera di .GLB",
        default=True,
    )


class CITYTOUR_OT_switch_camera(bpy.types.Operator):
    bl_idname = "citytour.switch_camera"
    bl_label = "Aktifkan Kamera & Pengaturan Optik"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.citytour_props
        cam = bpy.data.objects.get(props.kamera_aktif)
        if not cam:
            self.report({"WARNING"}, f"Kamera {props.kamera_aktif} tidak ditemukan!")
            return {"CANCELLED"}

        context.scene.camera = cam
        cam.data.type = props.tipe_proyeksi
        if props.tipe_proyeksi == "PERSP":
            cam.data.lens = props.focal_length
        cam.data.dof.use_dof = props.aktif_dof
        cam.data.dof.aperture_fstop = props.aperture_fstop

        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                for space in area.spaces:
                    if space.type == "VIEW_3D":
                        space.region_3d.view_perspective = "CAMERA"

        self.report({"INFO"}, f"Kamera aktif: {cam.name} ({props.tipe_proyeksi})")
        return {"FINISHED"}


class CITYTOUR_OT_toggle_play(bpy.types.Operator):
    bl_idname = "citytour.toggle_play"
    bl_label = "Play / Pause Simulasi Animasi"

    def execute(self, context):
        bpy.ops.screen.animation_play()
        return {"FINISHED"}


class CITYTOUR_OT_bake_day_night(bpy.types.Operator):
    bl_idname = "citytour.bake_day_night"
    bl_label = "Aktifkan Siklus Siang -> Malam (240 Frame)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        KeyframeAnimator.bake_siklus_siang_malam(total_frames=TOTAL_FRAMES)
        self.report({"INFO"}, "Siklus animasi Matahari & Lampu PJU otomatis (Frame 1-240) aktif!")
        return {"FINISHED"}


class CITYTOUR_OT_render_mp4(bpy.types.Operator):
    bl_idname = "citytour.render_mp4"
    bl_label = "Render Animasi ke Video MP4"
    bl_description = "Merender timeline (Frame 1-240) menjadi file video H.264 MP4"

    def execute(self, context):
        props = context.scene.citytour_props
        mp4_path = ExportPipelineManager.render_animasi_mp4(
            output_dir=props.output_dir,
            resolusi=props.render_res,
        )
        self.report({"INFO"}, f"Rendering MP4 dimulai -> {mp4_path}")
        return {"FINISHED"}


class CITYTOUR_OT_export_glb(bpy.types.Operator):
    bl_idname = "citytour.export_glb"
    bl_label = "Ekspor Kawasan Makro ke .GLB (Web 3D)"
    bl_description = "Mengekspor 3 Gedung, Taman, Kamera, & Animasi ke format glTF Binary (.glb)"

    def execute(self, context):
        props = context.scene.citytour_props
        glb_path = ExportPipelineManager.export_web_glb(
            output_dir=props.output_dir,
            sertakan_animasi=props.glb_include_anim,
        )
        self.report({"INFO"}, f"Ekspor Web 3D .GLB berhasil -> {glb_path}")
        return {"FINISHED"}


class CITYTOUR_PT_main_panel(bpy.types.Panel):
    bl_label = "Modul 4: Kamera, Animasi & Ekspor"
    bl_idname = "CITYTOUR_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "CityTour M4"

    def draw(self, context):
        layout = self.layout
        props = context.scene.citytour_props

        box1 = layout.box()
        box1.label(text="1. Kamera Virtual & Proyeksi", icon="CAMERA_DATA")
        box1.prop(props, "kamera_aktif")
        box1.prop(props, "tipe_proyeksi")
        box1.prop(props, "focal_length")
        box1.prop(props, "aktif_dof")
        box1.prop(props, "aperture_fstop")
        box1.operator("citytour.switch_camera", icon="VIEW_CAMERA")

        box2 = layout.box()
        box2.label(text="2. Kontrol Animasi & Siklus Waktu", icon="PLAY")
        box2.operator("citytour.toggle_play", icon="TIME")
        box2.operator("citytour.bake_day_night", icon="LIGHT_SUN")

        box3 = layout.box()
        box3.label(text="3. Render Video & Ekspor Web 3D", icon="EXPORT")
        box3.prop(props, "output_dir")
        box3.prop(props, "render_res")
        box3.operator("citytour.render_mp4", icon="RENDER_ANIMATION")
        box3.separator()
        box3.prop(props, "glb_include_anim")
        box3.operator("citytour.export_glb", icon="MESH_CUBE")


KELAS_UI_MODUL4 = (
    CityTourAppProps,
    CITYTOUR_OT_switch_camera,
    CITYTOUR_OT_toggle_play,
    CITYTOUR_OT_bake_day_night,
    CITYTOUR_OT_render_mp4,
    CITYTOUR_OT_export_glb,
    CITYTOUR_PT_main_panel,
)


def register_modul4_ui():
    for cls in KELAS_UI_MODUL4:
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        bpy.utils.register_class(cls)
    bpy.types.Scene.citytour_props = bpy.props.PointerProperty(type=CityTourAppProps)


