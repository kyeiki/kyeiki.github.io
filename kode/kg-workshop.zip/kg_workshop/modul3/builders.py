# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# MacroAssetBuilder — kota makro Modul 3.
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from ..core34.transform import Transform3DEngine
from ..core34.material import TextureMaterialFactory
from .engine import SceneManager, LightingRigManager
from ..config.makro import TEBAL_DINDING, TEBAL_SLAB_LANTAI, TINGGI_PER_LANTAI


# --------------------------------------------------------------------------
# 5. MacroAssetBuilder: Membangun 3 Gedung 2 Lantai, Jalan, Pohon, & PJU
# --------------------------------------------------------------------------
class MacroAssetBuilder:
    def __init__(self, mat_factory, palet, kol_utama, kol_lampu):
        self.mat_factory = mat_factory
        self.palet = palet
        self.kol_utama = kol_utama
        self.kol_lampu = kol_lampu

    def _mat(self, nama):
        spec = self.palet.get(nama, {"rgba": [0.8, 0.8, 0.8, 1.0]})
        return self.mat_factory.get_or_create(nama, spec)

    def buat_kotak(self, nama, dim, lokasi, rot=(0.0, 0.0, 0.0), mat_nama="dinding_interior", parent=None):
        bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0.0, 0.0, 0.0))
        o = bpy.context.active_object
        o.name = nama
        Transform3DEngine.terapkan_matriks(o, lokasi=lokasi, rotasi_euler=rot, skala=dim, parent=parent)
        SceneManager.generate_box_uv(o)
        o.data.materials.append(self._mat(mat_nama))
        SceneManager.pindahkan_ke_koleksi(o, self.kol_utama)
        return o

    def buat_silinder(self, nama, radius, tinggi, lokasi, rot=(0.0, 0.0, 0.0), mat_nama="tiang_lampu", parent=None):
        bpy.ops.mesh.primitive_cylinder_add(radius=1.0, depth=1.0, location=(0.0, 0.0, 0.0))
        o = bpy.context.active_object
        o.name = nama
        Transform3DEngine.terapkan_matriks(o, lokasi=lokasi, rotasi_euler=rot, skala=(radius, radius, tinggi), parent=parent)
        o.data.materials.append(self._mat(mat_nama))
        SceneManager.pindahkan_ke_koleksi(o, self.kol_utama)
        return o

    # --- A. PEMBANGUN GEDUNG 2 LANTAI (MULTI-FLOOR BUILDING) ---
    def bangun_gedung_dua_lantai(self, spec_gedung):
        nama_g = spec_gedung["nama"]
        x1, y1 = spec_gedung["min_xy"]
        x2, y2 = spec_gedung["max_xy"]
        wx, wy = abs(x2 - x1), abs(y2 - y1)
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        jml_lantai = int(spec_gedung.get("jumlah_lantai", 2))

        mat_eks = (
            "dinding_eksterior_a" if "Gedung_A" in nama_g
            else ("dinding_eksterior_b" if "Gedung_B" in nama_g else "dinding_eksterior_c")
        )

        # Root Empty Gedung (Hierarki Induk Gedung)
        root_g = bpy.data.objects.new(nama_g, None)
        root_g.empty_display_type = "CUBE"
        root_g.empty_display_size = 1.0
        bpy.context.scene.collection.objects.link(root_g)
        Transform3DEngine.terapkan_matriks(root_g, lokasi=(cx, cy, 0.0))
        SceneManager.pindahkan_ke_koleksi(root_g, self.kol_utama)

        for lt in range(jml_lantai):
            z_base = lt * TINGGI_PER_LANTAI
            z_mid = z_base + TINGGI_PER_LANTAI / 2.0

            # 1. Pelat Lantai (Floor Slab) & Lantai Keramik Interior
            self.buat_kotak(
                f"{nama_g}_Slab_Lt{lt+1}",
                [wx + 0.3, wy + 0.3, TEBAL_SLAB_LANTAI],
                (0.0, 0.0, z_base + TEBAL_SLAB_LANTAI / 2.0),
                mat_nama="slab_beton",
                parent=root_g,
            )
            self.buat_kotak(
                f"{nama_g}_LantaiKeramik_Lt{lt+1}",
                [wx - 0.2, wy - 0.2, 0.06],
                (0.0, 0.0, z_base + TEBAL_SLAB_LANTAI + 0.03),
                mat_nama="lantai_interior",
                parent=root_g,
            )

            # 2. Dinding Eksterior 4 Sisi + Barisan Jendela Kaca (Fasad)
            # Sisi Utara & Selatan
            for s_idx, y_off in enumerate([-wy / 2.0, wy / 2.0]):
                # Dinding Bawah (Spandrel) & Atas (Lintel)
                self.buat_kotak(
                    f"{nama_g}_DindingNS_{lt+1}_{s_idx}_Bawah",
                    [wx, TEBAL_DINDING, 0.95],
                    (0.0, y_off, z_base + 0.475),
                    mat_nama=mat_eks,
                    parent=root_g,
                )
                self.buat_kotak(
                    f"{nama_g}_DindingNS_{lt+1}_{s_idx}_Atas",
                    [wx, TEBAL_DINDING, 0.65],
                    (0.0, y_off, z_base + TINGGI_PER_LANTAI - 0.325),
                    mat_nama=mat_eks,
                    parent=root_g,
                )
                # Panel Kaca Fasad Sepanjang Dinding
                lebar_kaca = wx - 1.6
                self.buat_kotak(
                    f"{nama_g}_KacaFasadNS_{lt+1}_{s_idx}",
                    [lebar_kaca, 0.06, 1.60],
                    (0.0, y_off, z_base + 0.95 + 0.80),
                    mat_nama="kaca_fasad",
                    parent=root_g,
                )
                # Pilar Sudut & Mullion Kusen
                for px in [-wx / 2.0 + 0.4, 0.0, wx / 2.0 - 0.4]:
                    self.buat_kotak(
                        f"{nama_g}_PilarNS_{lt+1}_{s_idx}_{px:.1f}",
                        [0.45, TEBAL_DINDING + 0.08, TINGGI_PER_LANTAI],
                        (px, y_off, z_mid),
                        mat_nama="kusen_hitam",
                        parent=root_g,
                    )

            # Sisi Barat & Timur
            for s_idx, x_off in enumerate([-wx / 2.0, wx / 2.0]):
                self.buat_kotak(
                    f"{nama_g}_DindingEW_{lt+1}_{s_idx}",
                    [TEBAL_DINDING, wy, TINGGI_PER_LANTAI],
                    (x_off, 0.0, z_mid),
                    mat_nama=mat_eks,
                    parent=root_g,
                )
                self.buat_kotak(
                    f"{nama_g}_KacaFasadEW_{lt+1}_{s_idx}",
                    [0.08, wy * 0.55, 1.50],
                    (x_off, 0.0, z_base + 1.75),
                    mat_nama="kaca_fasad",
                    parent=root_g,
                )

            # 3. Partisi Dinding Dalam & Tangga Penghubung Lantai 1 -> Lantai 2
            self.buat_kotak(
                f"{nama_g}_PartisiDalam_Lt{lt+1}",
                [wx * 0.65, 0.14, TINGGI_PER_LANTAI - 0.2],
                (0.0, 0.0, z_mid),
                mat_nama="dinding_interior",
                parent=root_g,
            )
            if lt == 0:
                # Bangun Tangga Internal dari Lantai 1 ke Lantai 2
                jml_step = 10
                for st in range(jml_step):
                    t_step = (st + 1) * (TINGGI_PER_LANTAI / jml_step)
                    self.buat_kotak(
                        f"{nama_g}_TanggaLt1Ke2_{st}",
                        [0.35, 1.2, t_step],
                        (-wx * 0.25 + st * 0.36, -wy * 0.22, t_step / 2.0),
                        mat_nama="slab_beton",
                        parent=root_g,
                    )

            # 4. Pasang Point Light Interior di Plafon tiap Lantai (Materi 3)
            for lx in [-wx * 0.25, wx * 0.25]:
                LightingRigManager.tambah_point_light_interior(
                    nama=f"Point_Lantai{lt+1}_{nama_g}_{lx:.1f}",
                    lokasi_xyz=(lx, 0.0, z_base + TINGGI_PER_LANTAI - 0.45),
                    koleksi_lampu=self.kol_lampu,
                    parent=root_g,
                )

        # 5. Atap Rooftop, Parapet, & Unit Mesin HVAC di Lantai Paling Atas
        z_atap = jml_lantai * TINGGI_PER_LANTAI
        self.buat_kotak(
            f"{nama_g}_DakAtap",
            [wx + 0.5, wy + 0.5, 0.28],
            (0.0, 0.0, z_atap + 0.14),
            mat_nama="slab_beton",
            parent=root_g,
        )
        # Dinding Parapet Keliling Atap
        self.buat_kotak(f"{nama_g}_ParapetN", [wx + 0.5, 0.20, 0.65], (0.0, wy / 2.0 + 0.15, z_atap + 0.55), mat_nama=mat_eks, parent=root_g)
        self.buat_kotak(f"{nama_g}_ParapetS", [wx + 0.5, 0.20, 0.65], (0.0, -wy / 2.0 - 0.15, z_atap + 0.55), mat_nama=mat_eks, parent=root_g)
        # Unit HVAC Rooftop
        self.buat_kotak(f"{nama_g}_RooftopHVAC", [2.2, 1.4, 1.1], (wx * 0.2, 0.0, z_atap + 0.80), mat_nama="tiang_lampu", parent=root_g)

        return root_g

    # --- B. PEMBANGUN OBJEK LINGKUNGAN (POHON, PJU SPOTLIGHT, BANGKU, KOLAM, MOBIL) ---
    def bangun_pohon_modular(self, idx, xy):
        root = bpy.data.objects.new(f"Pohon_{idx:02d}", None)
        bpy.context.scene.collection.objects.link(root)
        Transform3DEngine.terapkan_matriks(root, lokasi=(xy[0], xy[1], 0.0))
        SceneManager.pindahkan_ke_koleksi(root, self.kol_utama)

        self.buat_silinder(f"Batang_{idx}", 0.22, 1.8, (0.0, 0.0, 0.9), mat_nama="batang_pohon", parent=root)
        # Tajuk daun bertingkat bergaya modular low-poly/LEGO
        self.buat_kotak(f"Daun1_{idx}", [1.8, 1.8, 1.1], (0.0, 0.0, 2.1), mat_nama="daun_pohon", parent=root)
        self.buat_kotak(f"Daun2_{idx}", [1.3, 1.3, 0.9], (0.0, 0.0, 2.9), rot=(0.0, 0.0, math.radians(45)), mat_nama="daun_pohon", parent=root)
        self.buat_kotak(f"Daun3_{idx}", [0.7, 0.7, 0.6], (0.0, 0.0, 3.5), mat_nama="daun_pohon", parent=root)
        return root

    def bangun_lampu_jalan_pju(self, idx, xy, arah_hadap_jalan_y):
        """Membangun Tiang PJU + Bohlam Emisif + Spot Light Sorot Jalan."""
        root = bpy.data.objects.new(f"TiangPJU_{idx:02d}", None)
        bpy.context.scene.collection.objects.link(root)
        rot_z = 0.0 if arah_hadap_jalan_y > 0 else math.pi
        Transform3DEngine.terapkan_matriks(root, lokasi=(xy[0], xy[1], 0.0), rotasi_euler=(0.0, 0.0, rot_z))
        SceneManager.pindahkan_ke_koleksi(root, self.kol_utama)

        # Tiang vertikal & lengan lampu menjorok ke jalan
        self.buat_silinder(f"Tiang_{idx}", 0.10, 4.8, (0.0, 0.0, 2.4), mat_nama="tiang_lampu", parent=root)
        self.buat_kotak(f"LenganPJU_{idx}", [0.16, 1.3, 0.14], (0.0, 0.55, 4.75), mat_nama="tiang_lampu", parent=root)
        self.buat_kotak(f"BohlamPJU_{idx}", [0.38, 0.55, 0.10], (0.0, 1.05, 4.65), mat_nama="bohlam_lampu", parent=root)

        # Pasang Spot Light tepat di bawah bohlam PJU
        LightingRigManager.tambah_spot_light_pju(
            nama=f"Spot_PJU_{idx:02d}",
            lokasi_xyz=(0.0, 1.05, 4.55),
            rot_z=0.0,
            koleksi_lampu=self.kol_lampu,
            parent=root,
        )
        return root

    def bangun_bangku_taman(self, idx, xy):
        root = bpy.data.objects.new(f"BangkuTaman_{idx:02d}", None)
        bpy.context.scene.collection.objects.link(root)
        Transform3DEngine.terapkan_matriks(root, lokasi=(xy[0], xy[1], 0.0))
        SceneManager.pindahkan_ke_koleksi(root, self.kol_utama)

        self.buat_kotak(f"Dudukan_{idx}", [1.6, 0.55, 0.08], (0.0, 0.0, 0.45), mat_nama="kayu_bangku", parent=root)
        self.buat_kotak(f"Sandaran_{idx}", [1.6, 0.08, 0.45], (0.0, 0.24, 0.70), mat_nama="kayu_bangku", parent=root)
        self.buat_kotak(f"KakiL_{idx}", [0.12, 0.50, 0.45], (-0.65, 0.0, 0.225), mat_nama="tiang_lampu", parent=root)
        self.buat_kotak(f"KakiR_{idx}", [0.12, 0.50, 0.45], (0.65, 0.0, 0.225), mat_nama="tiang_lampu", parent=root)
        return root

    def bangun_mobil_lego(self, idx, xy):
        warna = "mobil_merah" if idx % 2 == 0 else "mobil_biru"
        root = bpy.data.objects.new(f"MobilLego_{idx:02d}", None)
        bpy.context.scene.collection.objects.link(root)
        Transform3DEngine.terapkan_matriks(root, lokasi=(xy[0], xy[1], 0.0))
        SceneManager.pindahkan_ke_koleksi(root, self.kol_utama)

        self.buat_kotak(f"BodiBawah_{idx}", [2.6, 1.3, 0.50], (0.0, 0.0, 0.40), mat_nama=warna, parent=root)
        self.buat_kotak(f"KabinAtas_{idx}", [1.4, 1.15, 0.45], (-0.15, 0.0, 0.85), mat_nama="kaca_fasad", parent=root)
        for rx in [-0.8, 0.8]:
            for ry in [-0.65, 0.65]:
                self.buat_silinder(
                    f"Roda_{idx}_{rx}_{ry}", 0.28, 0.22, (rx, ry, 0.28),
                    rot=(math.radians(90), 0.0, 0.0), mat_nama="roda_hitam", parent=root,
                )
        return root

    def bangun_kawasan_lengkap(self, data_makro):
        wx, wy = data_makro["ukuran_kawasan"]
        cx, cy = wx / 2.0, wy / 2.0
        y_j1, y_j2 = data_makro["zona_jalan_y"]
        lebar_jalan = abs(y_j2 - y_j1)
        y_tengah_jalan = (y_j1 + y_j2) / 2.0

        # 1. Hamparan Dasar Taman Rumput Hijau
        self.buat_kotak("Tanah_TamanRumput", [wx + 4.0, wy + 4.0, 0.20], (cx, cy, -0.10), mat_nama="rumput_taman")

        # 2. Jalan Raya Aspal & Trotoar Kiri-Kanan
        self.buat_kotak("JalanRaya_Aspal", [wx + 4.0, lebar_jalan, 0.06], (cx, y_tengah_jalan, 0.03), mat_nama="aspal_jalan")
        self.buat_kotak("Trotoar_Utara", [wx + 4.0, 2.2, 0.14], (cx, y_j2 + 1.1, 0.07), mat_nama="trotoar_paving")
        self.buat_kotak("Trotoar_Selatan", [wx + 4.0, 2.2, 0.14], (cx, y_j1 - 1.1, 0.07), mat_nama="trotoar_paving")

        # 3. Marka Jalan Putih Putus-putus
        for idx, m_xy in enumerate(data_makro["marka"]):
            self.buat_kotak(f"MarkaJalan_{idx:02d}", [2.2, 0.22, 0.02], (m_xy[0], y_tengah_jalan, 0.07), mat_nama="marka_jalan")

        # 4. Kolam Air Mancur Plasa di antara Gedung A & Gedung B
        if data_makro["kolam_cells"]:
            kx = sum(p[0] for p in data_makro["kolam_cells"]) / len(data_makro["kolam_cells"])
            ky = sum(p[1] for p in data_makro["kolam_cells"]) / len(data_makro["kolam_cells"])
            self.buat_silinder("Kolam_BingkaiBeton", 2.8, 0.35, (kx, ky, 0.175), mat_nama="slab_beton")
            self.buat_silinder("Kolam_Air", 2.5, 0.30, (kx, ky, 0.20), mat_nama="air_kolam")
            self.buat_silinder("Tugu_AirMancur", 0.35, 1.4, (kx, ky, 0.70), mat_nama="kaca_fasad")

        # 5. Bangun 3 Gedung 2 Lantai
        for g_spec in data_makro["gedung"]:
            self.bangun_gedung_dua_lantai(g_spec)

        # 6. Bangun Pohon, Lampu PJU, Bangku Taman, & Mobil LEGO
        for idx, p_xy in enumerate(data_makro["pohon"]):
            self.bangun_pohon_modular(idx + 1, p_xy)

        for idx, l_xy in enumerate(data_makro["lampu_jalan"]):
            arah_y = 1.0 if l_xy[1] < y_tengah_jalan else -1.0
            self.bangun_lampu_jalan_pju(idx + 1, l_xy, arah_y)

        for idx, b_xy in enumerate(data_makro["bangku"]):
            self.bangun_bangku_taman(idx + 1, b_xy)

        for idx, c_xy in enumerate(data_makro["mobil"]):
            self.bangun_mobil_lego(idx + 1, c_xy)


