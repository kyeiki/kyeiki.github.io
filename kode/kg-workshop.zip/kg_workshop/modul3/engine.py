# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# SceneManager varian M3 + LightingRigManager lengkap (preset waktu, PJU).
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from ..core34.transform import Transform3DEngine


# --------------------------------------------------------------------------
# 2. SceneManager & Box UV Generator
# --------------------------------------------------------------------------
class SceneManager:
    @staticmethod
    def bersihkan_scene():
        if bpy.context.active_object and bpy.context.active_object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="SELECT")
        bpy.ops.object.delete()
        for block_list in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.lights):
            for item in list(block_list):
                block_list.remove(item)

    @staticmethod
    def buat_koleksi(nama_koleksi, parent_kol=None):
        if nama_koleksi in bpy.data.collections:
            return bpy.data.collections[nama_koleksi]
        kol = bpy.data.collections.new(nama_koleksi)
        if parent_kol:
            parent_kol.children.link(kol)
        else:
            bpy.context.scene.collection.children.link(kol)
        return kol

    @staticmethod
    def pindahkan_ke_koleksi(obj, koleksi):
        for c in list(obj.users_collection):
            c.objects.unlink(obj)
        koleksi.objects.link(obj)

    @staticmethod
    def generate_box_uv(obj):
        if not obj or obj.type != "MESH":
            return
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()
        for face in bm.faces:
            n = face.normal
            for loop in face.loops:
                co = loop.vert.co
                if abs(n.z) > 0.5:
                    loop[uv_layer].uv = (co.x, co.y)
                elif abs(n.x) > 0.5:
                    loop[uv_layer].uv = (co.y, co.z)
                else:
                    loop[uv_layer].uv = (co.x, co.z)
        bm.to_mesh(obj.data)
        bm.free()


# --------------------------------------------------------------------------
# 4. LightingRigManager: Inti Materi 3 (Directional, Point, Spot, Area & Sky)
# --------------------------------------------------------------------------
class LightingRigManager:
    """
    MATERI 3 - PENCAHAYAAN & LINGKUNGAN (LIGHTING & ENVIRONMENT):
    Mengatur 4 komponen pencahayaan utama + World Sky Shader:
      1. Sun Light (Directional) : Cahaya matahari global & bayangan tajam
      2. World Environment       : Langit prosedural (Sky Texture) & Ambient
      3. Street Spot Lights      : Lampu PJU sepanjang jalan dengan kerucut sorot
      4. Interior Point Lights   : Lampu plafon tiap lantai di dalam 3 gedung
      5. Plaza Area Light        : Fill light lembut di atas taman air mancur
    """

    PRESETS_WAKTU = {
        "DAY": {
            "sun_energy": 4.5,
            "sun_color": (1.0, 0.98, 0.92),
            "sun_rot_deg": (38.0, 15.0, -35.0),
            "sky_bg_color": (0.45, 0.68, 0.95, 1.0),
            "sky_strength": 1.2,
            "street_light_energy": 0.0,      # PJU mati saat siang
            "interior_light_energy": 60.0,   # Lampu kantor redup saat siang
            "glass_emission": 0.15,
            "bulb_emission": 0.5,
        },
        "SUNSET": {
            "sun_energy": 2.8,
            "sun_color": (1.0, 0.52, 0.22),
            "sun_rot_deg": (74.0, 12.0, -65.0),
            "sky_bg_color": (0.85, 0.42, 0.25, 1.0),
            "sky_strength": 0.75,
            "street_light_energy": 450.0,    # PJU mulai menyala hangat
            "interior_light_energy": 180.0,
            "glass_emission": 1.2,
            "bulb_emission": 6.0,
        },
        "NIGHT": {
            "sun_energy": 0.15,              # Cahaya bulan redup kebiruan
            "sun_color": (0.45, 0.62, 0.95),
            "sun_rot_deg": (42.0, -20.0, 25.0),
            "sky_bg_color": (0.02, 0.04, 0.09, 1.0),
            "sky_strength": 0.20,
            "street_light_energy": 900.0,    # PJU menyala terang di malam hari
            "interior_light_energy": 320.0,  # Gedung bersinar terang dari dalam
            "glass_emission": 2.5,
            "bulb_emission": 12.0,
        },
    }

    @classmethod
    def bangun_world_sky(cls):
        """Membangun World Shader dengan Sky Texture + Background Node."""
        scene = bpy.context.scene
        if not scene.world:
            scene.world = bpy.data.worlds.new("World_Makro_M3")
        world = scene.world
        world.use_nodes = True
        nodes = world.node_tree.nodes
        links = world.node_tree.links
        nodes.clear()

        out_node = nodes.new(type="ShaderNodeOutputWorld")
        out_node.location = (300, 0)

        bg_node = nodes.new(type="ShaderNodeBackground")
        bg_node.name = "World_BG"
        bg_node.location = (80, 0)
        bg_node.inputs["Color"].default_value = (0.45, 0.68, 0.95, 1.0)
        bg_node.inputs["Strength"].default_value = 1.0

        links.new(bg_node.outputs["Background"], out_node.inputs["Surface"])

        # Aktifkan bayangan EEVEE & Ambient Occlusion
        if hasattr(scene.eevee, "use_gtao"):
            scene.eevee.use_gtao = True
        if hasattr(scene.eevee, "use_bloom"):
            scene.eevee.use_bloom = True

    @classmethod
    def bangun_matahari_dan_area_plasa(cls, ukuran_kawasan, koleksi_lampu):
        wx, wy = ukuran_kawasan
        cx, cy = wx / 2.0, wy / 2.0

        # 1. Directional Light (SUN)
        light_data = bpy.data.lights.new(name="Sun_MatahariUtama", type="SUN")
        light_data.energy = 4.5
        light_data.color = (1.0, 0.98, 0.92)
        light_data.angle = math.radians(1.5)
        sun_obj = bpy.data.objects.new(name="Sun_MatahariUtama", object_data=light_data)
        bpy.context.scene.collection.objects.link(sun_obj)
        Transform3DEngine.terapkan_matriks(
            sun_obj,
            lokasi=(cx, cy, 35.0),
            rotasi_euler=(math.radians(38), math.radians(15), math.radians(-35)),
        )
        SceneManager.pindahkan_ke_koleksi(sun_obj, koleksi_lampu)

        # 2. Area Light di atas Plasa Air Mancur (Fill Light Taman)
        area_data = bpy.data.lights.new(name="Area_PlasaTaman", type="AREA")
        area_data.energy = 250.0
        area_data.color = (0.75, 0.92, 1.0)
        area_data.size = 8.0
        area_obj = bpy.data.objects.new(name="Area_PlasaTaman", object_data=area_data)
        bpy.context.scene.collection.objects.link(area_obj)
        Transform3DEngine.terapkan_matriks(area_obj, lokasi=(cx, cy + 5.5, 8.0))
        SceneManager.pindahkan_ke_koleksi(area_obj, koleksi_lampu)

    @classmethod
    def tambah_point_light_interior(cls, nama, lokasi_xyz, koleksi_lampu, parent=None):
        """Menambahkan lampu Point Light di plafon tiap lantai gedung."""
        pt_data = bpy.data.lights.new(name=nama, type="POINT")
        pt_data.energy = 120.0
        pt_data.color = (1.0, 0.92, 0.78)
        pt_data.shadow_soft_size = 0.5
        pt_obj = bpy.data.objects.new(name=nama, object_data=pt_data)
        bpy.context.scene.collection.objects.link(pt_obj)
        Transform3DEngine.terapkan_matriks(pt_obj, lokasi=lokasi_xyz, parent=parent)
        SceneManager.pindahkan_ke_koleksi(pt_obj, koleksi_lampu)
        return pt_obj

    @classmethod
    def tambah_spot_light_pju(cls, nama, lokasi_xyz, rot_z, koleksi_lampu, parent=None):
        """Menambahkan lampu Spot Light pada kepala tiang PJU."""
        sp_data = bpy.data.lights.new(name=nama, type="SPOT")
        sp_data.energy = 450.0
        sp_data.color = (1.0, 0.85, 0.55)
        sp_data.spot_size = math.radians(78.0)   # Sudut kerucut sorot lampu jalan
        sp_data.spot_blend = 0.45                # Kelembutan tepi kerucut cahaya
        sp_data.shadow_soft_size = 0.35
        sp_obj = bpy.data.objects.new(name=nama, object_data=sp_data)
        bpy.context.scene.collection.objects.link(sp_obj)
        Transform3DEngine.terapkan_matriks(
            sp_obj,
            lokasi=lokasi_xyz,
            rotasi_euler=(math.radians(15), 0.0, rot_z),
            parent=parent,
        )
        SceneManager.pindahkan_ke_koleksi(sp_obj, koleksi_lampu)
        return sp_obj

    @classmethod
    def terapkan_preset_waktu(cls, nama_preset="SUNSET", pju_nyala=True, interior_nyala=True):
        spec = cls.PRESETS_WAKTU.get(nama_preset, cls.PRESETS_WAKTU["SUNSET"])

        # 1. Update Sun Light
        sun_obj = bpy.data.objects.get("Sun_MatahariUtama")
        if sun_obj and sun_obj.type == "LIGHT":
            sun_obj.data.energy = spec["sun_energy"]
            sun_obj.data.color = spec["sun_color"]
            r_deg = spec["sun_rot_deg"]
            sun_obj.rotation_euler = (math.radians(r_deg[0]), math.radians(r_deg[1]), math.radians(r_deg[2]))

        # 2. Update World Sky Background
        world = bpy.context.scene.world
        if world and world.use_nodes:
            bg = world.node_tree.nodes.get("World_BG")
            if bg:
                bg.inputs["Color"].default_value = spec["sky_bg_color"]
                bg.inputs["Strength"].default_value = spec["sky_strength"]

        # 3. Update seluruh Spot Light PJU & Point Light Interior
        for obj in bpy.data.objects:
            if obj.type == "LIGHT":
                if obj.name.startswith("Spot_PJU"):
                    obj.data.energy = spec["street_light_energy"] if pju_nyala else 0.0
                elif obj.name.startswith("Point_Lantai"):
                    obj.data.energy = spec["interior_light_energy"] if interior_nyala else 0.0

        # 4. Update Emission Strength pada Kaca Gedung & Bohlam PJU
        for mat_name, em_val in [
            ("kaca_fasad", spec["glass_emission"] if interior_nyala else 0.05),
            ("bohlam_lampu", spec["bulb_emission"] if pju_nyala else 0.1),
        ]:
            mat = bpy.data.materials.get(mat_name)
            if mat and mat.use_nodes:
                bsdf = mat.node_tree.nodes.get("Principled BSDF")
                if bsdf and "Emission Strength" in bsdf.inputs:
                    bsdf.inputs["Emission Strength"].default_value = em_val


