# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Builder furnitur & denah Modul 2.
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from .engine import SceneManager, Transform3DEngine, TextureMaterialFactory


# --------------------------------------------------------------------------
# 4. AssetBuilder: Hierarki Modular LEGO (Parent-Child) & Transformasi 3D
# --------------------------------------------------------------------------
class AssetBuilder:
    """
    MATERI 2 - MODULAR LEGO BUILDER:
    Alih-alih menggabungkan mesh dengan bpy.ops.object.join() yang merusak
    koordinat lokal tiap sub-bagian, AssetBuilder merakit komponen sebagai
    HIERARKI PARENT-CHILD (Scene Graph) menggunakan Transform3DEngine.
    """

    def __init__(self, mat_factory, palet):
        self.mat_factory = mat_factory
        self.palet = palet
        self._registry = {
            "box": self._bangun_kotak,
            "silinder": self._bangun_silinder,
            "lego_brick": self._bangun_bata_lego,
            "menara_lego": self._bangun_menara_lego,
            "meja_kerja": self._bangun_meja_kerja,
            "set_ruang_r": self._bangun_set_ruang_r,
            "rak_arsip": self._bangun_rak_arsip,
            "wastafel": self._bangun_wastafel,
            "meja_pantry": self._bangun_meja_pantry,
            "tangga_darurat": self._bangun_tangga_darurat,
        }

    def _mat(self, nama_mat):
        if nama_mat not in self.palet:
            return self.mat_factory.get_or_create(nama_mat, {"rgba": [0.8, 0.8, 0.8, 1.0]})
        return self.mat_factory.get_or_create(nama_mat, self.palet[nama_mat])

    def membangun(self, spec):
        fn = self._registry.get(spec["type"])
        if fn is None:
            raise ValueError(f"Tipe aset tak dikenal: {spec['type']!r}")
        return fn(spec)

    def _bangun_kotak(self, spec):
        dim = spec["dimensions"]
        di = spec.get("di", [0.0, 0.0])
        z = spec.get("z", dim[2] / 2.0)
        rot = spec.get("rot", [0.0, 0.0, 0.0])
        skala = spec.get("scale", [1.0, 1.0, 1.0])
        shear = spec.get("shear", [0.0, 0.0])
        parent = spec.get("parent", None)

        # Buat kubus satuan (size=1.0), lalu transformasikan menggunakan Matriks 4x4
        bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0.0, 0.0, 0.0))
        o = bpy.context.active_object
        o.name = spec.get("name", spec.get("nama", "Kotak"))

        skala_total = (dim[0] * skala[0], dim[1] * skala[1], dim[2] * skala[2])
        M = Transform3DEngine.komposisi_trs(
            lokasi=(di[0], di[1], z),
            rotasi_euler=rot,
            skala=skala_total,
            shear=shear,
        )
        if parent is not None:
            o.parent = parent
            o.matrix_parent_inverse = Matrix.Identity(4)
            o.matrix_local = M
        else:
            o.matrix_world = M

        SceneManager.generate_box_uv(o)
        o.data.materials.append(self._mat(spec["material"]))
        return o

    def _bangun_silinder(self, spec):
        r = spec.get("radius", 0.25)
        t = spec.get("depth", 1.0)
        di = spec.get("di", [0.0, 0.0])
        z = spec.get("z", t / 2.0)
        rot = spec.get("rot", [0.0, 0.0, 0.0])
        skala = spec.get("scale", [1.0, 1.0, 1.0])
        parent = spec.get("parent", None)

        bpy.ops.mesh.primitive_cylinder_add(radius=1.0, depth=1.0, location=(0.0, 0.0, 0.0))
        o = bpy.context.active_object
        o.name = spec.get("name", spec.get("nama", "Silinder"))

        Transform3DEngine.terapkan_matriks(
            o,
            lokasi=(di[0], di[1], z),
            rotasi_euler=rot,
            skala=(r * skala[0], r * skala[1], t * skala[2]),
            parent=parent,
        )
        o.data.materials.append(self._mat(spec["material"]))
        return o

    def _bangun_bata_lego(self, spec):
        """
        Membangun 1 Balok LEGO Modular (Studs X * Studs Y) dengan hierarki Parent-Child.
        Saat balok induk ditranslasikan/dirotasi/diskalakan, seluruh stud di atasnya
        ikut bertransformasi secara otomatis melalui perkalian matriks parent.
        """
        studs_x = int(spec.get("studs_x", 2))
        studs_y = int(spec.get("studs_y", 4))
        unit = float(spec.get("unit_size", 0.25))
        tinggi_bata = float(spec.get("height", 0.30))
        mat_name = spec.get("material", "lego_merah")

        wx, wy = studs_x * unit, studs_y * unit
        di = spec.get("di", [0.0, 0.0])
        z_alas = float(spec.get("z", 0.0))
        rot = spec.get("rot", [0.0, 0.0, 0.0])
        skala = spec.get("scale", [1.0, 1.0, 1.0])

        # Buat Empty sebagai Root Pivot di tengah alas balok LEGO
        root = bpy.data.objects.new(spec.get("nama", "LegoBrick"), None)
        root.empty_display_type = "PLAIN_AXES"
        root.empty_display_size = 0.2
        bpy.context.scene.collection.objects.link(root)

        Transform3DEngine.terapkan_matriks(
            root,
            lokasi=(di[0], di[1], z_alas),
            rotasi_euler=rot,
            skala=skala,
            parent=spec.get("parent", None),
        )

        # Badan utama balok LEGO (anak dari root)
        self._bangun_kotak({
            "name": f"{root.name}_Body",
            "dimensions": [wx * 0.98, wy * 0.98, tinggi_bata],
            "di": [0.0, 0.0],
            "z": tinggi_bata / 2.0,
            "material": mat_name,
            "parent": root,
        })

        # Stud silinder di atas balok LEGO (anak dari root)
        tinggi_stud = unit * 0.22
        radius_stud = unit * 0.30
        start_x = -wx / 2.0 + unit / 2.0
        start_y = -wy / 2.0 + unit / 2.0
        for ix in range(studs_x):
            for iy in range(studs_y):
                sx = start_x + ix * unit
                sy = start_y + iy * unit
                self._bangun_silinder({
                    "name": f"{root.name}_Stud_{ix}_{iy}",
                    "radius": radius_stud,
                    "depth": tinggi_stud,
                    "di": [sx, sy],
                    "z": tinggi_bata + tinggi_stud / 2.0,
                    "material": mat_name,
                    "parent": root,
                })
        return root

    def _bangun_menara_lego(self, spec):
        """Membangun struktur modular bertumpuk dari beberapa Lego Brick (Hierarchy Demo)."""
        di = spec.get("di", [0.0, 0.0])
        rot = spec.get("rot", [0.0, 0.0, 0.0])
        skala = spec.get("scale", [1.0, 1.0, 1.0])

        root = bpy.data.objects.new(spec.get("nama", "MenaraLego"), None)
        root.empty_display_type = "ARROWS"
        root.empty_display_size = 0.5
        bpy.context.scene.collection.objects.link(root)
        Transform3DEngine.terapkan_matriks(root, lokasi=(di[0], di[1], 0.0), rotasi_euler=rot, skala=skala)

        lapis = [
            ("lego_merah",  4, 4, 0.00, 0.0),
            ("lego_kuning", 3, 3, 0.30, math.radians(15)),
            ("lego_biru",   2, 4, 0.60, math.radians(30)),
            ("lego_hijau",  2, 2, 0.90, math.radians(45)),
        ]
        for idx, (warna, sx, sy, z_pos, r_z) in enumerate(lapis):
            self._bangun_bata_lego({
                "nama": f"{root.name}_Lapis{idx+1}",
                "studs_x": sx, "studs_y": sy,
                "unit_size": 0.28, "height": 0.30,
                "di": [0.0, 0.0], "z": z_pos,
                "rot": [0.0, 0.0, r_z],
                "material": warna,
                "parent": root,
            })
        return root

    def _rakit_hierarki_lokal(self, spec, daftar_komponen):
        """
        Membangun grup furnitur menggunakan Root Empty (Hierarchy Transform)
        sehingga seluruh bagian anak tetap memiliki matriks lokal masing-masing.
        """
        di = spec.get("di", [0.0, 0.0])
        z_root = float(spec.get("z", 0.0))
        rot = spec.get("rot", [0.0, 0.0, 0.0])
        skala = spec.get("scale", [1.0, 1.0, 1.0])

        root = bpy.data.objects.new(spec.get("nama", "GrupLego"), None)
        root.empty_display_type = "PLAIN_AXES"
        root.empty_display_size = 0.35
        bpy.context.scene.collection.objects.link(root)

        Transform3DEngine.terapkan_matriks(
            root,
            lokasi=(di[0], di[1], z_root),
            rotasi_euler=rot,
            skala=skala,
        )

        for idx, komp in enumerate(daftar_komponen):
            k_spec = dict(komp)
            k_spec["name"] = f"{root.name}_part{idx+1}"
            k_spec["parent"] = root
            self.membangun(k_spec)
        return root

    def _bangun_meja_kerja(self, spec):
        komp = [
            {"type": "box", "dimensions": [1.4, 0.7, 0.05], "di": [0.0, 0.0], "z": 0.73, "material": "kayu_meja"},
            {"type": "box", "dimensions": [0.06, 0.66, 0.71], "di": [-0.65, 0.0], "z": 0.355, "material": "logam_abu"},
            {"type": "box", "dimensions": [0.06, 0.66, 0.71], "di": [0.65, 0.0], "z": 0.355, "material": "logam_abu"},
            {"type": "box", "dimensions": [1.42, 0.05, 1.15], "di": [0.0, 0.35], "z": 0.575, "material": "partisi_kubikel"},
            {"type": "box", "dimensions": [0.52, 0.04, 0.32], "di": [0.0, 0.15], "z": 0.98, "material": "layar_monitor"},
            {"type": "box", "dimensions": [0.48, 0.48, 0.07], "di": [0.0, -0.55], "z": 0.46, "material": "kursi_kantor"},
            {"type": "box", "dimensions": [0.46, 0.06, 0.48], "di": [0.0, -0.77], "z": 0.72, "material": "kursi_kantor"},
            {"type": "silinder", "radius": 0.06, "depth": 0.44, "di": [0.0, -0.55], "z": 0.22, "material": "logam_abu"},
        ]
        return self._rakit_hierarki_lokal(spec, komp)

    def _bangun_set_ruang_r(self, spec):
        komp = [
            {"type": "box", "dimensions": [0.95, 0.45, 0.05], "di": [0.0, 0.12], "z": 0.73, "material": "kayu_meja"},
            {"type": "box", "dimensions": [0.38, 0.04, 0.26], "di": [0.0, 0.22], "z": 0.90, "material": "layar_monitor"},
            {"type": "box", "dimensions": [0.40, 0.40, 0.45], "di": [0.0, -0.22], "z": 0.225, "material": "kursi_kantor"},
        ]
        return self._rakit_hierarki_lokal(spec, komp)

    def _bangun_rak_arsip(self, spec):
        komp = []
        for sz in [0.20, 0.75, 1.30, 1.85]:
            komp.append({"type": "box", "dimensions": [1.35, 0.48, 0.04], "di": [0.0, 0.0], "z": sz, "material": "logam_abu"})
            if sz < 1.80:
                komp.append({"type": "box", "dimensions": [1.10, 0.38, 0.32], "di": [0.0, 0.0], "z": sz + 0.18, "material": "kardus_arsip"})
        return self._rakit_hierarki_lokal(spec, komp)

    def _bangun_wastafel(self, spec):
        komp = [
            {"type": "box", "dimensions": [1.60, 0.52, 0.82], "di": [0.0, 0.0], "z": 0.41, "material": "keramik_putih"},
            {"type": "box", "dimensions": [1.50, 0.04, 0.95], "di": [0.0, -0.24], "z": 1.35, "material": "kaca_jendela"},
        ]
        return self._rakit_hierarki_lokal(spec, komp)

    def _bangun_meja_pantry(self, spec):
        komp = [
            {"type": "box", "dimensions": [2.2, 0.60, 0.85], "di": [0.0, 0.0], "z": 0.425, "material": "kayu_meja"},
            {"type": "box", "dimensions": [2.24, 0.64, 0.05], "di": [0.0, 0.0], "z": 0.875, "material": "keramik_putih"},
        ]
        return self._rakit_hierarki_lokal(spec, komp)

    def _bangun_tangga_darurat(self, spec):
        panjang = spec.get("panjang", 4.0)
        lebar = spec.get("lebar", 1.2)
        jml_anak = 8
        dx, dz = panjang / float(jml_anak), 2.4 / float(jml_anak)
        komp = []
        for i in range(jml_anak):
            x_pos = -panjang / 2.0 + (i + 0.5) * dx
            t_blok = (i + 1) * dz
            komp.append({
                "type": "box", "dimensions": [dx * 0.96, lebar, t_blok],
                "di": [x_pos, 0.0], "z": t_blok / 2.0, "material": "lantai_tangga",
            })
        return self._rakit_hierarki_lokal(spec, komp)


# --------------------------------------------------------------------------
# 5. DenahBuilder: Membangun Lantai Bertekstur, Dinding Bata & Aset Modular
# --------------------------------------------------------------------------
class DenahBuilder:
    def __init__(self, builder, cfg_rumah):
        self.builder = builder
        self.cfg = cfg_rumah
        self.tinggi = float(cfg_rumah.get("tinggi_dinding", 3.0))
        self.tebal = float(cfg_rumah.get("tebal_dinding", 0.15))

    @staticmethod
    def _potong_dengan_celah(a1, a2, celah_list):
        batas = [(min(a1, a2), max(a1, a2))]
        for c in celah_list:
            baru = []
            for (s, e) in batas:
                if c["ke"] <= s or c["dari"] >= e:
                    baru.append((s, e))
                else:
                    if c["dari"] > s:
                        baru.append((s, c["dari"]))
                    if c["ke"] < e:
                        baru.append((c["ke"], e))
            batas = baru
        return [(s, e) for (s, e) in batas if e - s > 0.01]

    def _bangun_dinding(self):
        for seg in self.cfg.get("segmen_dinding", []):
            x1, y1 = float(seg["dari"][0]), float(seg["dari"][1])
            x2, y2 = float(seg["ke"][0]), float(seg["ke"][1])
            horizontal = abs(y1 - y2) < 1e-4
            mat = seg.get("material", "dinding_interior")
            celah_list = seg.get("celah", [])

            a1, a2 = (min(x1, x2), max(x1, x2)) if horizontal else (min(y1, y2), max(y1, y2))
            for idx, (s, e) in enumerate(self._potong_dengan_celah(a1, a2, celah_list)):
                panjang = e - s
                tengah = (s + e) / 2.0
                dim = [panjang, self.tebal, self.tinggi] if horizontal else [self.tebal, panjang, self.tinggi]
                pos = [tengah, y1] if horizontal else [x1, tengah]
                self.builder.membangun({
                    "type": "box", "name": f"{seg['nama']}_seg{idx}",
                    "dimensions": dim, "di": pos, "z": self.tinggi / 2.0, "material": mat,
                })

    def _bangun_lantai(self):
        for z in self.cfg.get("zona_lantai", []):
            x1, y1 = float(z["min_xy"][0]), float(z["min_xy"][1])
            x2, y2 = float(z["max_xy"][0]), float(z["max_xy"][1])
            self.builder.membangun({
                "type": "box", "name": z["nama"],
                "dimensions": [abs(x2 - x1), abs(y2 - y1), 0.10],
                "di": [(x1 + x2) / 2.0, (y1 + y2) / 2.0],
                "z": -0.05, "material": z.get("material", "lantai_koridor"),
            })

    def _bangun_furnitur(self):
        for f in self.cfg.get("furnitur", []):
            self.builder.membangun(f)

    def bangun_semua(self):
        self._bangun_lantai()
        self._bangun_dinding()
        self._bangun_furnitur()


