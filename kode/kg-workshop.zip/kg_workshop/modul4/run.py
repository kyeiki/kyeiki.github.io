# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Orkestrasi Modul 4 (badan fungsi verbatim dari monolith).
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from ..config.makro import PETA_MAKRO_ASCII, CONFIG_MATERIAL_MODUL4, SKALA_MAKRO_METER
from ..config.animasi import TOTAL_FRAMES
from .parser import AsciiMacroParser
from .engine import SceneManager, LightingRigManager
from ..core34.material import TextureMaterialFactory
from .builders import MacroAnimatedBuilder
from .anim import CameraRigManager, KeyframeAnimator
from .ui import register_modul4_ui

BLENDER_AVAILABLE = True


# ==============================================================================
# BAGIAN 5: ORKESTRASI UTAMA MODUL 4
# ==============================================================================
def jalankan_modul_4(ascii_makro=PETA_MAKRO_ASCII):
    parser = AsciiMacroParser(scale=SKALA_MAKRO_METER)
    data_makro = parser.parse(ascii_makro)

    if BLENDER_AVAILABLE:
        SceneManager.bersihkan_scene()
        scene = bpy.context.scene
        scene.frame_start = 1
        scene.frame_end = TOTAL_FRAMES
        scene.frame_current = 1
        scene.render.fps = 24

        kol_utama = SceneManager.buat_koleksi("KawasanMakro_Modul4")
        kol_lampu = SceneManager.buat_koleksi("LightingRig_Modul4", kol_utama)
        kol_cam = SceneManager.buat_koleksi("CameraRig_Modul4", kol_utama)

        LightingRigManager.bangun_world_dan_lampu(data_makro["ukuran_kawasan"], kol_lampu)
        builder = MacroAnimatedBuilder(TextureMaterialFactory(), CONFIG_MATERIAL_MODUL4, kol_utama, kol_lampu)
        mobil_utama = builder.bangun_kawasan_lengkap(data_makro, total_frames=TOTAL_FRAMES)

        CameraRigManager.bangun_semua_kamera(
            data_makro["ukuran_kawasan"],
            kol_cam,
            mobil_utama=mobil_utama,
            total_frames=TOTAL_FRAMES,
        )

        KeyframeAnimator.bake_siklus_siang_malam(total_frames=TOTAL_FRAMES)
        register_modul4_ui()

        for area in bpy.context.screen.areas:
            if area.type == "VIEW_3D":
                for space in area.spaces:
                    if space.type == "VIEW_3D":
                        space.shading.type = "RENDERED"
                        space.shading.use_scene_lights_render = True
                        space.shading.use_scene_world_render = True
                        space.region_3d.view_perspective = "CAMERA"

        print(
            f"MATERI 4 OK: Simulasi Kamera Spline, Animasi, Render MP4, & Ekspor .GLB "
            f"siap digunakan di panel 'CityTour M4'!"
        )
    return data_makro


