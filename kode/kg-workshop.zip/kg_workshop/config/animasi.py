# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Parameter animasi Modul 4 (sumber: modul4 BAGIAN 1).

TOTAL_FRAMES      = 240   # Durasi loop animasi = 10 detik (24 fps)


