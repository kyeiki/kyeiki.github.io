# -*- coding: utf-8 -*-
"""KG Workshop — add-on Workshop "Blender: Newbie → Master" (JTK POLBAN).

Paket dibangun otomatis dari monolith modul2/3/4 + skrip legacy Modul 1 oleh
tools/extract_kgworkshop.py (kelas disalin verbatim; kelas yang drift antar
modul disimpan sebagai varian per modul). Panel: View3D > Sidebar (N) > KG Workshop.
"""
bl_info = {
    "name": "KG Workshop (Komputer Grafik)",
    "author": "JTK POLBAN - Komputer Grafik",
    "version": (1, 0, 0),
    "blender": (4, 3, 0),
    "location": "View3D > Sidebar (N) > KG Workshop",
    "description": "Workshop Blender Newbie -> Master: jalankan Modul 1-4 & Capstone City Tour",
    "category": "Learn",
}

import bpy

from . import runner
from .modul2.ui import DAFTAR_KELAS_UI, register_lego_ui
from .modul3.ui import KELAS_UI_MODUL3, register_modul3_ui
from .modul4.ui import KELAS_UI_MODUL4, register_modul4_ui

_TARGETS = (
    ("1", "1 · Modul 1 — Denah ASCII → 3D"),
    ("2", "2 · Modul 2 — Transformasi & Tekstur"),
    ("3", "3 · Modul 3 — Pencahayaan & Kota"),
    ("4", "4 · Modul 4 — Kamera, Animasi & Ekspor"),
    ("capstone", "★ Capstone — City Tour Kampus"),
)


class KGWS_OT_run_module(bpy.types.Operator):
    """Jalankan tahap workshop pilihan dari paket kg_workshop"""

    bl_idname = "kgws.run_module"
    bl_label = "Jalankan Tahap Workshop"
    bl_options = {"REGISTER", "UNDO"}

    target: bpy.props.StringProperty()

    def execute(self, context):
        fn = {
            "1": runner.jalankan_modul_1,
            "2": runner.jalankan_modul_2,
            "3": runner.jalankan_modul_3,
            "4": runner.jalankan_modul_4,
            "capstone": runner.jalankan_capstone,
        }.get(self.target)
        if fn is None:
            self.report({"ERROR"}, f"Target tidak dikenal: {self.target}")
            return {"CANCELLED"}
        try:
            fn()
        except Exception as ex:  # noqa: BLE001 - laporan ke UI Blender
            self.report({"ERROR"}, f"KG Workshop gagal: {ex}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"KG Workshop: tahap {self.target} selesai")
        return {"FINISHED"}


class KGWS_PT_main_panel(bpy.types.Panel):
    bl_label = "KG Workshop"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "KG Workshop"

    def draw(self, context):
        col = self.layout.column()
        box = col.box()
        box.label(text="Workshop Newbie → Master", icon="GRADUATE")
        for key, label in _TARGETS:
            col.operator("kgws.run_module", text=label).target = key


_CLASSES = (KGWS_OT_run_module, KGWS_PT_main_panel)
_ALL_UI = (DAFTAR_KELAS_UI, KELAS_UI_MODUL3, KELAS_UI_MODUL4)
_POINTERS = ("lego_app_props", "macrolight_props", "citytour_props")


def register():
    for cls in _CLASSES:
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        bpy.utils.register_class(cls)
    register_lego_ui()
    register_modul3_ui()
    register_modul4_ui()


def unregister():
    for attr in _POINTERS:
        try:
            delattr(bpy.types.Scene, attr)
        except Exception:
            pass
    for lst in _ALL_UI:
        for cls in lst:
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


if __name__ == "__main__":
    register()
