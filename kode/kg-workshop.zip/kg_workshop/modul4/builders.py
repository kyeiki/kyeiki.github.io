# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# MacroAnimatedBuilder — kota beranimasi Modul 4.
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from ..core34.transform import Transform3DEngine
from .engine import SceneManager
from .anim import KeyframeAnimator
from ..config.makro import TEBAL_DINDING, TEBAL_SLAB_LANTAI, TINGGI_PER_LANTAI


# --------------------------------------------------------------------------
# 8. MacroAnimatedBuilder: Membangun 3 Gedung 2 Lantai + Lift + Mobil + HVAC
# --------------------------------------------------------------------------
class MacroAnimatedBuilder:
    def __init__(self, mat_factory, palet, kol_utama, kol_lampu):
        self.mat_factory = mat_factory
        self.palet = palet
        self.kol_utama = kol_utama
        self.kol_lampu = kol_lampu

    def _mat(self, nama):
        spec = self.palet.get(nama, {"rgba": [0.8, 0.8, 0.8, 1.0]})
        return self.mat_factory.get_or_create(nama, spec)

    def buat_kotak(self, nama, dim, lokasi, rot=(0.0, 0.0, 0.0), mat_nama="dinding_interior", parent=None):
        bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0.0, 0.0, 0.0))
        o = bpy.context.active_object
        o.name = nama
        Transform3DEngine.terapkan_matriks(o, lokasi=lokasi, rotasi_euler=rot, skala=dim, parent=parent)
        SceneManager.generate_box_uv(o)
        o.data.materials.append(self._mat(mat_nama))
        SceneManager.pindahkan_ke_koleksi(o, self.kol_utama)
        return o

    def buat_silinder(self, nama, radius, tinggi, lokasi, rot=(0.0, 0.0, 0.0), mat_nama="tiang_lampu", parent=None):
        bpy.ops.mesh.primitive_cylinder_add(radius=1.0, depth=1.0, location=(0.0, 0.0, 0.0))
        o = bpy.context.active_object
        o.name = nama
        Transform3DEngine.terapkan_matriks(o, lokasi=lokasi, rotasi_euler=rot, skala=(radius, radius, tinggi), parent=parent)
        o.data.materials.append(self._mat(mat_nama))
        SceneManager.pindahkan_ke_koleksi(o, self.kol_utama)
        return o

    def bangun_gedung_dua_lantai(self, spec_gedung, total_frames=240):
        nama_g = spec_gedung["nama"]
        x1, y1 = spec_gedung["min_xy"]
        x2, y2 = spec_gedung["max_xy"]
        wx, wy = abs(x2 - x1), abs(y2 - y1)
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        jml_lantai = int(spec_gedung.get("jumlah_lantai", 2))

        mat_eks = (
            "dinding_eksterior_a" if "Gedung_A" in nama_g
            else ("dinding_eksterior_b" if "Gedung_B" in nama_g else "dinding_eksterior_c")
        )

        root_g = bpy.data.objects.new(nama_g, None)
        bpy.context.scene.collection.objects.link(root_g)
        Transform3DEngine.terapkan_matriks(root_g, lokasi=(cx, cy, 0.0))
        SceneManager.pindahkan_ke_koleksi(root_g, self.kol_utama)

        for lt in range(jml_lantai):
            z_base = lt * TINGGI_PER_LANTAI
            z_mid = z_base + TINGGI_PER_LANTAI / 2.0

            self.buat_kotak(f"{nama_g}_Slab_Lt{lt+1}", [wx + 0.3, wy + 0.3, TEBAL_SLAB_LANTAI], (0.0, 0.0, z_base + TEBAL_SLAB_LANTAI / 2.0), mat_nama="slab_beton", parent=root_g)
            self.buat_kotak(f"{nama_g}_Lantai_Lt{lt+1}", [wx - 0.2, wy - 0.2, 0.06], (0.0, 0.0, z_base + TEBAL_SLAB_LANTAI + 0.03), mat_nama="lantai_interior", parent=root_g)

            for s_idx, y_off in enumerate([-wy / 2.0, wy / 2.0]):
                self.buat_kotak(f"{nama_g}_DindingNS_{lt+1}_{s_idx}_B", [wx, TEBAL_DINDING, 0.95], (0.0, y_off, z_base + 0.475), mat_nama=mat_eks, parent=root_g)
                self.buat_kotak(f"{nama_g}_DindingNS_{lt+1}_{s_idx}_A", [wx, TEBAL_DINDING, 0.65], (0.0, y_off, z_base + TINGGI_PER_LANTAI - 0.325), mat_nama=mat_eks, parent=root_g)
                self.buat_kotak(f"{nama_g}_KacaNS_{lt+1}_{s_idx}", [wx - 1.6, 0.06, 1.60], (0.0, y_off, z_base + 1.75), mat_nama="kaca_fasad", parent=root_g)
                for px in [-wx / 2.0 + 0.4, 0.0, wx / 2.0 - 0.4]:
                    self.buat_kotak(f"{nama_g}_PilarNS_{lt+1}_{s_idx}_{px:.1f}", [0.45, TEBAL_DINDING + 0.08, TINGGI_PER_LANTAI], (px, y_off, z_mid), mat_nama="kusen_hitam", parent=root_g)

            for s_idx, x_off in enumerate([-wx / 2.0, wx / 2.0]):
                self.buat_kotak(f"{nama_g}_DindingEW_{lt+1}_{s_idx}", [TEBAL_DINDING, wy, TINGGI_PER_LANTAI], (x_off, 0.0, z_mid), mat_nama=mat_eks, parent=root_g)

            for lx in [-wx * 0.25, wx * 0.25]:
                pt_data = bpy.data.lights.new(name=f"Point_Lantai{lt+1}_{nama_g}_{lx:.1f}", type="POINT")
                pt_data.energy = 180.0
                pt_data.color = (1.0, 0.92, 0.78)
                pt_obj = bpy.data.objects.new(name=pt_data.name, object_data=pt_data)
                bpy.context.scene.collection.objects.link(pt_obj)
                Transform3DEngine.terapkan_matriks(pt_obj, lokasi=(lx, 0.0, z_base + TINGGI_PER_LANTAI - 0.45), parent=root_g)
                SceneManager.pindahkan_ke_koleksi(pt_obj, self.kol_lampu)

        z_atap = jml_lantai * TINGGI_PER_LANTAI
        self.buat_kotak(f"{nama_g}_DakAtap", [wx + 0.5, wy + 0.5, 0.28], (0.0, 0.0, z_atap + 0.14), mat_nama="slab_beton", parent=root_g)
        self.buat_kotak(f"{nama_g}_UnitHVAC", [2.2, 1.4, 0.9], (wx * 0.2, 0.0, z_atap + 0.70), mat_nama="tiang_lampu", parent=root_g)
        kipas = self.buat_kotak(f"{nama_g}_KipasHVAC", [1.3, 0.18, 0.08], (wx * 0.2, 0.0, z_atap + 1.22), mat_nama="kaca_lift", parent=root_g)
        KeyframeAnimator.animasikan_kipas_hvac(kipas, putaran_penuh=10, total_frames=total_frames)

        if "Gedung_A" in nama_g:
            self.buat_kotak("ShaftLift_GedungA", [0.15, 1.8, z_atap + 0.4], (wx / 2.0 + 0.85, 0.0, (z_atap + 0.4) / 2.0), mat_nama="kusen_hitam", parent=root_g)
            kabin_lift = self.buat_kotak("KabinLift_GedungA", [1.4, 1.5, 2.2], (wx / 2.0 + 0.75, 0.0, 1.3), mat_nama="kaca_lift", parent=root_g)
            KeyframeAnimator.animasikan_lift_gedung(kabin_lift, z_lantai1=1.35, z_lantai2=1.35 + TINGGI_PER_LANTAI, total_frames=total_frames)

        return root_g

    def bangun_pohon_modular(self, idx, xy):
        root = bpy.data.objects.new(f"Pohon_{idx:02d}", None)
        bpy.context.scene.collection.objects.link(root)
        Transform3DEngine.terapkan_matriks(root, lokasi=(xy[0], xy[1], 0.0))
        SceneManager.pindahkan_ke_koleksi(root, self.kol_utama)
        self.buat_silinder(f"Batang_{idx}", 0.22, 1.8, (0.0, 0.0, 0.9), mat_nama="batang_pohon", parent=root)
        self.buat_kotak(f"Daun1_{idx}", [1.8, 1.8, 1.1], (0.0, 0.0, 2.1), mat_nama="daun_pohon", parent=root)
        self.buat_kotak(f"Daun2_{idx}", [1.3, 1.3, 0.9], (0.0, 0.0, 2.9), rot=(0.0, 0.0, math.radians(45)), mat_nama="daun_pohon", parent=root)
        return root

    def bangun_lampu_jalan_pju(self, idx, xy, arah_y):
        root = bpy.data.objects.new(f"TiangPJU_{idx:02d}", None)
        bpy.context.scene.collection.objects.link(root)
        Transform3DEngine.terapkan_matriks(root, lokasi=(xy[0], xy[1], 0.0), rotasi_euler=(0.0, 0.0, 0.0 if arah_y > 0 else math.pi))
        SceneManager.pindahkan_ke_koleksi(root, self.kol_utama)

        self.buat_silinder(f"Tiang_{idx}", 0.10, 4.8, (0.0, 0.0, 2.4), mat_nama="tiang_lampu", parent=root)
        self.buat_kotak(f"LenganPJU_{idx}", [0.16, 1.3, 0.14], (0.0, 0.55, 4.75), mat_nama="tiang_lampu", parent=root)
        self.buat_kotak(f"BohlamPJU_{idx}", [0.38, 0.55, 0.10], (0.0, 1.05, 4.65), mat_nama="bohlam_lampu", parent=root)

        sp_data = bpy.data.lights.new(name=f"Spot_PJU_{idx:02d}", type="SPOT")
        sp_data.energy = 450.0
        sp_data.color = (1.0, 0.85, 0.55)
        sp_data.spot_size = math.radians(78.0)
        sp_data.spot_blend = 0.45
        sp_obj = bpy.data.objects.new(name=sp_data.name, object_data=sp_data)
        bpy.context.scene.collection.objects.link(sp_obj)
        Transform3DEngine.terapkan_matriks(sp_obj, lokasi=(0.0, 1.05, 4.55), rotasi_euler=(math.radians(15), 0.0, 0.0), parent=root)
        SceneManager.pindahkan_ke_koleksi(sp_obj, self.kol_lampu)
        return root

    def bangun_mobil_animated(self, idx, y_jalur, x_start, x_end, total_frames=240):
        warna = "mobil_merah" if idx == 1 else "mobil_biru"
        arah_x = 1.0 if x_end > x_start else -1.0
        rot_z = 0.0 if arah_x > 0 else math.pi

        root = bpy.data.objects.new(f"MobilLego_{idx:02d}", None)
        bpy.context.scene.collection.objects.link(root)
        Transform3DEngine.terapkan_matriks(root, lokasi=(x_start, y_jalur, 0.0), rotasi_euler=(0.0, 0.0, rot_z))
        SceneManager.pindahkan_ke_koleksi(root, self.kol_utama)

        self.buat_kotak(f"BodiBawah_{idx}", [2.6, 1.3, 0.50], (0.0, 0.0, 0.40), mat_nama=warna, parent=root)
        self.buat_kotak(f"KabinAtas_{idx}", [1.4, 1.15, 0.45], (-0.15, 0.0, 0.85), mat_nama="kaca_fasad", parent=root)
        self.buat_kotak(f"HeadlightL_{idx}", [0.12, 0.25, 0.16], (1.32, 0.42, 0.45), mat_nama="lampu_mobil", parent=root)
        self.buat_kotak(f"HeadlightR_{idx}", [0.12, 0.25, 0.16], (1.32, -0.42, 0.45), mat_nama="lampu_mobil", parent=root)

        hl_data = bpy.data.lights.new(name=f"Spot_Mobil_{idx}", type="SPOT")
        hl_data.energy = 600.0
        hl_data.color = (1.0, 0.96, 0.82)
        hl_data.spot_size = math.radians(55.0)
        hl_obj = bpy.data.objects.new(name=hl_data.name, object_data=hl_data)
        bpy.context.scene.collection.objects.link(hl_obj)
        Transform3DEngine.terapkan_matriks(hl_obj, lokasi=(1.4, 0.0, 0.5), rotasi_euler=(math.radians(82), 0.0, math.radians(-90)), parent=root)
        SceneManager.pindahkan_ke_koleksi(hl_obj, self.kol_lampu)

        roda_list = []
        for rx in [-0.8, 0.8]:
            for ry in [-0.65, 0.65]:
                r_obj = self.buat_silinder(
                    f"Roda_{idx}_{rx}_{ry}", 0.28, 0.22, (rx, ry, 0.28),
                    rot=(math.radians(90), 0.0, 0.0), mat_nama="roda_hitam", parent=root,
                )
                roda_list.append(r_obj)

        KeyframeAnimator.animasikan_mobil_lalu_lintas(root, roda_list, x_start, x_end, total_frames=total_frames)
        return root

    def bangun_kawasan_lengkap(self, data_makro, total_frames=240):
        wx, wy = data_makro["ukuran_kawasan"]
        cx, cy = wx / 2.0, wy / 2.0
        y_j1, y_j2 = data_makro["zona_jalan_y"]
        lebar_jalan = abs(y_j2 - y_j1)
        y_tengah_jalan = (y_j1 + y_j2) / 2.0

        self.buat_kotak("Tanah_TamanRumput", [wx + 4.0, wy + 4.0, 0.20], (cx, cy, -0.10), mat_nama="rumput_taman")
        self.buat_kotak("JalanRaya_Aspal", [wx + 4.0, lebar_jalan, 0.06], (cx, y_tengah_jalan, 0.03), mat_nama="aspal_jalan")
        self.buat_kotak("Trotoar_Utara", [wx + 4.0, 2.2, 0.14], (cx, y_j2 + 1.1, 0.07), mat_nama="trotoar_paving")
        self.buat_kotak("Trotoar_Selatan", [wx + 4.0, 2.2, 0.14], (cx, y_j1 - 1.1, 0.07), mat_nama="trotoar_paving")

        for idx, m_xy in enumerate(data_makro["marka"]):
            self.buat_kotak(f"MarkaJalan_{idx:02d}", [2.2, 0.22, 0.02], (m_xy[0], y_tengah_jalan, 0.07), mat_nama="marka_jalan")

        if data_makro["kolam_cells"]:
            kx = sum(p[0] for p in data_makro["kolam_cells"]) / len(data_makro["kolam_cells"])
            ky = sum(p[1] for p in data_makro["kolam_cells"]) / len(data_makro["kolam_cells"])
            self.buat_silinder("Kolam_BingkaiBeton", 2.8, 0.35, (kx, ky, 0.175), mat_nama="slab_beton")
            self.buat_silinder("Kolam_Air", 2.5, 0.30, (kx, ky, 0.20), mat_nama="air_kolam")
            self.buat_silinder("Tugu_AirMancur", 0.35, 1.4, (kx, ky, 0.70), mat_nama="kaca_fasad")

        for g_spec in data_makro["gedung"]:
            self.bangun_gedung_dua_lantai(g_spec, total_frames=total_frames)

        for idx, p_xy in enumerate(data_makro["pohon"]):
            self.bangun_pohon_modular(idx + 1, p_xy)

        for idx, l_xy in enumerate(data_makro["lampu_jalan"]):
            arah_y = 1.0 if l_xy[1] < y_tengah_jalan else -1.0
            self.bangun_lampu_jalan_pju(idx + 1, l_xy, arah_y)

        mobil_1 = self.bangun_mobil_animated(1, y_tengah_jalan - 0.85, x_start=2.0, x_end=wx - 2.0, total_frames=total_frames)
        self.bangun_mobil_animated(2, y_tengah_jalan + 0.85, x_start=wx - 2.0, x_end=2.0, total_frames=total_frames)
        return mobil_1


