# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# AsciiDenahParser — varian Modul 2 (kompatibel Modul 1).
import json
import math
import re
from collections import deque


# ==============================================================================
# BAGIAN 3: KELAS AsciiDenahParser (Tetap kompatibel dengan Modul 1)
# ==============================================================================
class AsciiDenahParser:
    def __init__(self, scale_x=0.5, scale_y=0.5, tinggi_dinding=3.0, tebal_dinding=0.15):
        self.scale_x = float(scale_x)
        self.scale_y = float(scale_y)
        self.tinggi_dinding = float(tinggi_dinding)
        self.tebal_dinding = float(tebal_dinding)

    @staticmethod
    def _normalisasi_baris(ascii_text):
        raw_lines = [l.rstrip("\r\n") for l in ascii_text.strip().splitlines() if l.strip()]
        if not raw_lines:
            raise ValueError("Teks ASCII kosong!")
        max_len = max(len(l) for l in raw_lines)
        grid = []
        for l in raw_lines:
            if len(l) < max_len and "---" in l:
                diff = max_len - len(l)
                runs = [(m.end() - m.start(), m.start(), m.end()) for m in re.finditer(r"-+", l)]
                runs.sort(reverse=True)
                _, start_idx, _ = runs[0]
                l = l[:start_idx] + ("-" * diff) + l[start_idx:]
            grid.append(l.ljust(max_len))
        return grid

    @staticmethod
    def _is_horizontal_wall_char(grid, r, c):
        W = len(grid[0])
        ch = grid[r][c]
        if ch == "+":
            return True
        if ch == "-":
            left = grid[r][c - 1] if c > 0 else " "
            right = grid[r][c + 1] if c + 1 < W else " "
            return (left in ("+", "-")) or (right in ("+", "-"))
        return False

    @staticmethod
    def _is_vertical_wall_char(grid, r, c):
        return grid[r][c] in ("+", "|")

    def _is_any_wall(self, grid, r, c):
        ch = grid[r][c]
        if ch in ("+", "|"):
            return True
        if ch == "-":
            return self._is_horizontal_wall_char(grid, r, c)
        return False

    def _rc_to_xy(self, r, c, max_r):
        x = round(c * self.scale_x, 3)
        y = round((max_r - r) * self.scale_y, 3)
        return x, y

    def _ekstrak_ruangan(self, grid):
        H, W = len(grid), len(grid[0])
        max_r = H - 1
        visited = [[False] * W for _ in range(H)]
        rooms = []

        for r in range(H):
            for c in range(W):
                if not visited[r][c] and not self._is_any_wall(grid, r, c):
                    q = deque([(r, c)])
                    visited[r][c] = True
                    cells = []
                    while q:
                        cr, cc = q.popleft()
                        cells.append((cr, cc))
                        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                            nr, nc = cr + dr, cc + dc
                            if 0 <= nr < H and 0 <= nc < W and not visited[nr][nc] and not self._is_any_wall(grid, nr, nc):
                                visited[nr][nc] = True
                                q.append((nr, nc))

                    min_r, max_r_cell = min(p[0] for p in cells), max(p[0] for p in cells)
                    min_c, max_c_cell = min(p[1] for p in cells), max(p[1] for p in cells)
                    r1, r2 = max(0, min_r - 1), min(max_r, max_r_cell + 1)
                    c1, c2 = max(0, min_c - 1), min(W - 1, max_c_cell + 1)

                    cell_set = set(cells)
                    row_texts = []
                    for rr in range(min_r, max_r_cell + 1):
                        s = "".join(grid[rr][cc] for cc in range(min_c, max_c_cell + 1) if (rr, cc) in cell_set)
                        s_clean = " ".join(s.split())
                        if s_clean:
                            row_texts.append(s_clean)
                    raw_label = " ".join(row_texts)
                    norm_label = raw_label
                    if raw_label.replace(" ", "") == "R.ARSIP":
                        norm_label = "R. ARSIP"
                    elif raw_label.replace(" ", "") == "CORIDOR":
                        norm_label = "CORIDOR"

                    x1, y2 = self._rc_to_xy(r1, c1, max_r)
                    x2, y1 = self._rc_to_xy(r2, c2, max_r)
                    rooms.append({
                        "id": len(rooms), "r1": r1, "r2": r2, "c1": c1, "c2": c2,
                        "x1": min(x1, x2), "x2": max(x1, x2), "y1": min(y1, y2), "y2": max(y1, y2),
                        "area_cells": len(cells), "raw_label": raw_label, "label": norm_label,
                    })
        return rooms

    def _ekstrak_segmen_dinding(self, grid):
        H, W = len(grid), len(grid[0])
        max_r = H - 1
        horiz_segments, vert_segments = [], []

        for r in range(H):
            c = 0
            while c < W:
                if self._is_horizontal_wall_char(grid, r, c):
                    start_c = c
                    has_dash = False
                    while c < W and self._is_horizontal_wall_char(grid, r, c):
                        if grid[r][c] == "-":
                            has_dash = True
                        c += 1
                    end_c = c - 1
                    if has_dash and end_c > start_c:
                        x1, y = self._rc_to_xy(r, start_c, max_r)
                        x2, _ = self._rc_to_xy(r, end_c, max_r)
                        mat = "dinding_eksterior" if r in (0, max_r) else ("dinding_core" if 11 <= r <= 21 else "dinding_interior")
                        horiz_segments.append({
                            "nama": f"Dinding_H_R{r:02d}_C{start_c:02d}_{end_c:02d}",
                            "orientasi": "H", "r": r, "c1": start_c, "c2": end_c,
                            "dari": [x1, y], "ke": [x2, y], "material": mat, "celah": [],
                        })
                else:
                    c += 1

        for c in range(W):
            r = 0
            while r < H:
                if self._is_vertical_wall_char(grid, r, c):
                    start_r = r
                    has_pipe = False
                    while r < H and self._is_vertical_wall_char(grid, r, c):
                        if grid[r][c] == "|":
                            has_pipe = True
                        r += 1
                    end_r = r - 1
                    if has_pipe:
                        if start_r > 0 and self._is_horizontal_wall_char(grid, start_r - 1, c):
                            start_r -= 1
                        if end_r + 1 < H and self._is_horizontal_wall_char(grid, end_r + 1, c):
                            end_r += 1
                        if end_r == start_r:
                            end_r = min(max_r, start_r + 1)
                        x, y2 = self._rc_to_xy(start_r, c, max_r)
                        _, y1 = self._rc_to_xy(end_r, c, max_r)
                        mat = "dinding_eksterior" if c in (0, W - 1) else ("dinding_core" if (12 <= c <= 58 and start_r >= 11 and end_r <= 21) else "dinding_interior")
                        vert_segments.append({
                            "nama": f"Dinding_V_C{c:02d}_R{start_r:02d}_{end_r:02d}",
                            "orientasi": "V", "c": c, "r1": start_r, "r2": end_r,
                            "dari": [x, min(y1, y2)], "ke": [x, max(y1, y2)], "material": mat, "celah": [],
                        })
                else:
                    r += 1
        return horiz_segments, vert_segments

    @staticmethod
    def _tambah_celah_ke_segmen(seg_list, orientasi, garis_idx, pos_tengah, lebar_celah, tinggi_bukaan=2.1, ambang_bawah=0.0):
        half = round(lebar_celah / 2.0, 3)
        c_dari, c_ke = round(pos_tengah - half, 3), round(pos_tengah + half, 3)
        for seg in seg_list:
            if orientasi == "H" and seg["r"] == garis_idx:
                s_min, s_max = min(seg["dari"][0], seg["ke"][0]), max(seg["dari"][0], seg["ke"][0])
            elif orientasi == "V" and seg["c"] == garis_idx:
                s_min, s_max = min(seg["dari"][1], seg["ke"][1]), max(seg["dari"][1], seg["ke"][1])
            else:
                continue
            if c_dari >= s_min + 0.05 and c_ke <= s_max - 0.05:
                if not any(not (c_ke <= ex["dari"] or c_dari >= ex["ke"]) for ex in seg["celah"]):
                    seg["celah"].append({"dari": c_dari, "ke": c_ke, "tinggi_bukaan": round(tinggi_bukaan, 2), "ambang_bawah": round(ambang_bawah, 2)})
                return True
        return False

    def _injeksi_pintu_dan_jendela_otomatis(self, rooms, horiz_segments, vert_segments, max_r, max_c):
        for rm in rooms:
            lbl = rm["label"].upper()
            r1, r2, c1, c2 = rm["r1"], rm["r2"], rm["c1"], rm["c2"]
            cx, cy = round((rm["x1"] + rm["x2"]) / 2.0, 2), round((rm["y1"] + rm["y2"]) / 2.0, 2)
            width_x, height_y = rm["x2"] - rm["x1"], rm["y2"] - rm["y1"]
            lebar_pintu = max(0.7, min(0.9, round(min(width_x, height_y) * 0.45, 2)))

            if lbl == "[R]" and r1 == 0:
                self._tambah_celah_ke_segmen(horiz_segments, "H", r2, cx, lebar_pintu, 2.1, 0.0)
                self._tambah_celah_ke_segmen(horiz_segments, "H", r1, cx, min(1.2, width_x * 0.5), 1.0, 1.0)
            elif lbl == "R" and r2 == max_r:
                self._tambah_celah_ke_segmen(horiz_segments, "H", r1, cx, lebar_pintu, 2.1, 0.0)
                self._tambah_celah_ke_segmen(horiz_segments, "H", r2, cx, min(1.0, width_x * 0.5), 1.0, 1.0)
            elif "ARSIP" in lbl:
                self._tambah_celah_ke_segmen(vert_segments, "V", c2 if c1 == 0 else c1, cy, 1.0, 2.1, 0.0)
                self._tambah_celah_ke_segmen(vert_segments, "V", c1 if c1 == 0 else c2, cy, 1.6, 1.0, 1.1)
            elif "CORIDOR" in lbl or "KORIDOR" in lbl:
                self._tambah_celah_ke_segmen(horiz_segments, "H", r1, cx, min(2.0, width_x - 0.6), 2.5, 0.0)
                self._tambah_celah_ke_segmen(horiz_segments, "H", r2, cx, min(2.0, width_x - 0.6), 2.5, 0.0)
            elif "TOILET" in lbl:
                self._tambah_celah_ke_segmen(vert_segments, "V", c2, cy, 0.9, 2.1, 0.0)
            elif "LIFT-1" in lbl or "LIFT-2" in lbl:
                self._tambah_celah_ke_segmen(vert_segments, "V", c2, cy, 1.1, 2.2, 0.0)
            elif lbl in ("LIFT", "[LIFT]"):
                self._tambah_celah_ke_segmen(vert_segments, "V", c1, cy, 0.8, 2.1, 0.0)
            elif "AHU" in lbl:
                self._tambah_celah_ke_segmen(vert_segments, "V", c1, cy, 0.9, 2.1, 0.0)
            elif "PANTRY" in lbl:
                self._tambah_celah_ke_segmen(horiz_segments, "H", r1, cx, 0.9, 2.1, 0.0)
            elif "TANGGA" in lbl:
                self._tambah_celah_ke_segmen(vert_segments, "V", c1 if c1 == 38 else c2, cy, 0.85, 2.1, 0.0)
            elif "PANEL" in lbl:
                self._tambah_celah_ke_segmen(vert_segments, "V", c1, cy, 0.8, 2.1, 0.0)

    def _tentukan_material_lantai(self, label):
        lbl = label.upper()
        if "WORK STATION" in lbl or "TAMU" in lbl: return "lantai_workstation"
        if "CORIDOR" in lbl or lbl == "": return "lantai_koridor"
        if lbl in ("[R]", "R") or "KAMAR" in lbl: return "lantai_ruang_r"
        if "ARSIP" in lbl: return "lantai_arsip"
        if "TOILET" in lbl or "MANDI" in lbl: return "lantai_toilet"
        if "PANTRY" in lbl or "DAPUR" in lbl: return "lantai_pantry"
        if "TANGGA" in lbl: return "lantai_tangga"
        if "LIFT" in lbl: return "lantai_lift"
        return "lantai_teknis"

    def _bangun_furnitur_dan_label_otomatis(self, rooms):
        furnitur, label_ruang = [], []
        for rm in rooms:
            lbl = rm["label"].upper()
            x1, x2, y1, y2 = rm["x1"], rm["x2"], rm["y1"], rm["y2"]
            cx, cy = round((x1 + x2) / 2.0, 2), round((y1 + y2) / 2.0, 2)
            wx, wy = round(x2 - x1, 2), round(y2 - y1, 2)

            if rm["label"]:
                label_ruang.append({
                    "teks": rm["label"], "di": [cx, cy],
                    "ukuran": 0.45 if wx >= 6.0 else (0.28 if wx >= 2.5 else 0.22),
                })

            if "WORK STATION" in lbl:
                is_utara = "UTARA" in lbl
                y_base = round(y1 + 1.8, 2) if is_utara else round(y2 - 1.8, 2)
                y_row2 = round(y1 + 3.4, 2) if is_utara else round(y2 - 3.4, 2)
                for idx, x_pos in enumerate([5.5, 9.0, 12.5, 21.5, 25.0, 28.5]):
                    if x1 + 1.0 < x_pos < x2 - 1.0:
                        # Menambahkan atribut transformasi 3D eksplisit (scale & rotasi)
                        furnitur.append({
                            "nama": f"Kubikel_{'U' if is_utara else 'S'}_R1_{idx+1}",
                            "type": "meja_kerja", "di": [x_pos, y_base],
                            "rot": [0.0, 0.0, 0.0 if is_utara else round(math.pi, 4)],
                            "scale": [1.0, 1.0, 1.0],
                        })
                        furnitur.append({
                            "nama": f"Kubikel_{'U' if is_utara else 'S'}_R2_{idx+1}",
                            "type": "meja_kerja", "di": [x_pos, y_row2],
                            "rot": [0.0, 0.0, round(math.pi, 4) if is_utara else 0.0],
                            "scale": [1.0, 1.0, 1.0],
                        })
                # Tambahkan Monumen LEGO Modular di tengah Workstation (Materi 2)
                furnitur.append({
                    "nama": f"MenaraLego_{'Utara' if is_utara else 'Selatan'}",
                    "type": "menara_lego",
                    "di": [cx, round((y_base + y_row2) / 2.0, 2)],
                    "rot": [0.0, 0.0, round(math.pi / 4.0, 4)],
                    "scale": [1.1, 1.1, 1.1],
                })

            elif lbl in ("[R]", "R"):
                furnitur.append({
                    "nama": f"SetRuangR_{rm['id']}", "type": "set_ruang_r",
                    "di": [cx, cy], "rot": [0.0, 0.0, round(math.pi, 4) if lbl == "[R]" else 0.0],
                })
            elif "ARSIP" in lbl:
                for idx, ry in enumerate([round(y1 + 1.4, 2), round(cy, 2), round(y2 - 1.4, 2)]):
                    furnitur.append({
                        "nama": f"RakArsip_{rm['id']}_{idx+1}", "type": "rak_arsip",
                        "di": [cx, ry], "rot": [0.0, 0.0, round(math.pi / 2.0, 4)],
                    })
            elif "TOILET" in lbl:
                furnitur.append({"nama": f"Wastafel_{rm['id']}", "type": "wastafel", "di": [cx, round(y1 + 0.4, 2)]})
            elif "PANTRY" in lbl:
                furnitur.append({"nama": f"MejaPantry_{rm['id']}", "type": "meja_pantry", "di": [cx, round(y1 + 0.45, 2)]})
            elif "TANGGA" in lbl:
                furnitur.append({
                    "nama": f"TanggaDarurat_{rm['id']}", "type": "tangga_darurat",
                    "di": [cx, cy], "panjang": round(max(2.5, wx - 1.2), 2), "lebar": round(max(0.8, wy - 0.3), 2),
                })
        return furnitur, label_ruang

    def parse_to_dict(self, ascii_text):
        grid = self._normalisasi_baris(ascii_text)
        H, W = len(grid), len(grid[0])
        max_r, max_c = H - 1, W - 1
        rooms = self._ekstrak_ruangan(grid)
        horiz_segments, vert_segments = self._ekstrak_segmen_dinding(grid)
        self._injeksi_pintu_dan_jendela_otomatis(rooms, horiz_segments, vert_segments, max_r, max_c)

        segmen_dinding = [
            {
                "nama": s["nama"], "dari": s["dari"], "ke": s["ke"],
                "material": s["material"], "celah": sorted(s["celah"], key=lambda item: item["dari"]),
            }
            for s in horiz_segments + vert_segments
        ]
        zona_lantai = [
            {
                "nama": f"Lantai_{rm['id']:02d}_{re.sub(r'[^A-Za-z0-9]+', '_', rm['label'] or 'Koridor').strip('_')}",
                "min_xy": [rm["x1"], rm["y1"]], "max_xy": [rm["x2"], rm["y2"]],
                "material": self._tentukan_material_lantai(rm["label"]),
            }
            for rm in rooms
        ]
        furnitur, label_ruang = self._bangun_furnitur_dan_label_otomatis(rooms)
        return {
            "meta": {"modul": "Modul 2 - Transformasi 3D, Hierarki LEGO & Texture Shader"},
            "rumah": {
                "grid": [round(max_c * self.scale_x, 2), round(max_r * self.scale_y, 2)],
                "tinggi_dinding": self.tinggi_dinding,
                "tebal_dinding": self.tebal_dinding,
                "segmen_dinding": segmen_dinding,
                "zona_lantai": zona_lantai,
                "furnitur": furnitur,
                "label_ruang": label_ruang,
            },
        }


