# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Orkestrasi Modul 3 (badan fungsi verbatim dari monolith).
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
from ..config.makro import PETA_MAKRO_ASCII, CONFIG_MATERIAL_MODUL3, SKALA_MAKRO_METER
from .parser import AsciiMacroParser
from .engine import SceneManager, LightingRigManager
from ..core34.material import TextureMaterialFactory
from .builders import MacroAssetBuilder
from .ui import register_modul3_ui

BLENDER_AVAILABLE = True


# ==============================================================================
# BAGIAN 6: ORKESTRASI UTAMA & PENGATURAN KAMERA MAKRO
# ==============================================================================
def atur_kamera_dan_viewport_makro(ukuran_kawasan):
    if not BLENDER_AVAILABLE:
        return
    wx, wy = ukuran_kawasan
    cx, cy = wx / 2.0, wy / 2.0

    bpy.ops.object.camera_add(location=(cx - 12.0, -wy * 0.55, 22.0))
    cam = bpy.context.active_object
    cam.name = "Kamera_Masterplan_M3"
    cam.rotation_euler = (math.radians(56), 0.0, math.radians(-14))
    cam.data.lens = 28.0
    bpy.context.scene.camera = cam

    # Aktifkan mode shading MATERIAL atau RENDERED beserta Scene Lights & World
    for area in bpy.context.screen.areas:
        if area.type == "VIEW_3D":
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    space.shading.type = "RENDERED"
                    space.shading.use_scene_lights_render = True
                    space.shading.use_scene_world_render = True


def jalankan_modul_3(ascii_makro=PETA_MAKRO_ASCII):
    parser = AsciiMacroParser(scale=SKALA_MAKRO_METER)
    data_makro = parser.parse(ascii_makro)

    if BLENDER_AVAILABLE:
        SceneManager.bersihkan_scene()
        kol_utama = SceneManager.buat_koleksi("KawasanMakro_Modul3")
        kol_lampu = SceneManager.buat_koleksi("LightingRig_Modul3", kol_utama)

        LightingRigManager.bangun_world_sky()
        LightingRigManager.bangun_matahari_dan_area_plasa(data_makro["ukuran_kawasan"], kol_lampu)

        builder = MacroAssetBuilder(TextureMaterialFactory(), CONFIG_MATERIAL_MODUL3, kol_utama, kol_lampu)
        builder.bangun_kawasan_lengkap(data_makro)

        # Set default ke suasana Sore / Golden Hour agar efek lampu jalan & matahari terlihat dramatis
        LightingRigManager.terapkan_preset_waktu("SUNSET", pju_nyala=True, interior_nyala=True)
        atur_kamera_dan_viewport_makro(data_makro["ukuran_kawasan"])
        register_modul3_ui()

        print(
            f"MATERI 3 OK: Kawasan {data_makro['ukuran_kawasan'][0]}x{data_makro['ukuran_kawasan'][1]}m "
            f"({len(data_makro['gedung'])} Gedung 2 Lantai, {len(data_makro['pohon'])} Pohon, "
            f"{len(data_makro['lampu_jalan'])} Lampu Jalan SpotLight) berhasil dibangun!"
        )
    return data_makro


