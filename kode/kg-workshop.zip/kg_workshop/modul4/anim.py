# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Mesin animasi Modul 4: keyframe, kamera, ekspor.
import bpy
import bmesh
import math
from mathutils import Matrix, Vector, Euler
import os
import tempfile

from ..core34.transform import Transform3DEngine
from .engine import SceneManager


# --------------------------------------------------------------------------
# 5. KeyframeAnimator: Interpolasi LINEAR vs BEZIER
# --------------------------------------------------------------------------
class KeyframeAnimator:
    @staticmethod
    def set_interpolasi_fcurve(obj_atau_data, mode="LINEAR"):
        if not obj_atau_data or not obj_atau_data.animation_data or not obj_atau_data.animation_data.action:
            return
        for fcurve in obj_atau_data.animation_data.action.fcurves:
            for kp in fcurve.keyframe_points:
                kp.interpolation = mode

    @classmethod
    def animasikan_lift_gedung(cls, kabin_obj, z_lantai1=0.35, z_lantai2=3.55, total_frames=240):
        x0, y0, _ = kabin_obj.location
        jadwal = [
            (1,   z_lantai1),
            (30,  z_lantai1),
            (95,  z_lantai2),
            (145, z_lantai2),
            (210, z_lantai1),
            (total_frames, z_lantai1),
        ]
        for frame, z_val in jadwal:
            kabin_obj.location = (x0, y0, z_val)
            kabin_obj.keyframe_insert(data_path="location", frame=frame)
        cls.set_interpolasi_fcurve(kabin_obj, mode="BEZIER")

    @classmethod
    def animasikan_mobil_lalu_lintas(cls, mobil_root, roda_list, x_mulai, x_akhir, total_frames=240):
        _, y0, z0 = mobil_root.location
        jarak = abs(x_akhir - x_mulai)
        radius_roda = 0.28
        sudut_putar_total = jarak / radius_roda

        mobil_root.location = (x_mulai, y0, z0)
        mobil_root.keyframe_insert(data_path="location", frame=1)

        mobil_root.location = (x_akhir, y0, z0)
        mobil_root.keyframe_insert(data_path="location", frame=total_frames)
        cls.set_interpolasi_fcurve(mobil_root, mode="LINEAR")

        arah_putar = 1.0 if x_akhir > x_mulai else -1.0
        for roda in roda_list:
            roda.rotation_euler = (math.radians(90), 0.0, 0.0)
            roda.keyframe_insert(data_path="rotation_euler", frame=1)
            roda.rotation_euler = (math.radians(90), arah_putar * sudut_putar_total, 0.0)
            roda.keyframe_insert(data_path="rotation_euler", frame=total_frames)
            cls.set_interpolasi_fcurve(roda, mode="LINEAR")

    @classmethod
    def animasikan_kipas_hvac(cls, kipas_obj, putaran_penuh=8, total_frames=240):
        kipas_obj.rotation_euler = (0.0, 0.0, 0.0)
        kipas_obj.keyframe_insert(data_path="rotation_euler", frame=1)
        kipas_obj.rotation_euler = (0.0, 0.0, math.pi * 2.0 * putaran_penuh)
        kipas_obj.keyframe_insert(data_path="rotation_euler", frame=total_frames)
        cls.set_interpolasi_fcurve(kipas_obj, mode="LINEAR")

    @classmethod
    def bake_siklus_siang_malam(cls, total_frames=240):
        sun = bpy.data.objects.get("Sun_MatahariUtama")
        if sun:
            tahap_sun = [
                (1,   3.5, (1.0, 0.96, 0.88), (35.0,  15.0, -30.0)),
                (110, 2.8, (1.0, 0.50, 0.20), (76.0,  12.0, -65.0)),
                (170, 0.2, (0.45, 0.62, 0.95), (45.0, -20.0,  25.0)),
                (total_frames, 0.2, (0.45, 0.62, 0.95), (45.0, -20.0,  25.0)),
            ]
            for f, energy, col, rot_deg in tahap_sun:
                sun.data.energy = energy
                sun.data.color = col
                sun.data.keyframe_insert(data_path="energy", frame=f)
                sun.data.keyframe_insert(data_path="color", frame=f)

                sun.rotation_euler = (math.radians(rot_deg[0]), math.radians(rot_deg[1]), math.radians(rot_deg[2]))
                sun.keyframe_insert(data_path="rotation_euler", frame=f)

        # Keyframe warna langit World Background mengikuti fase waktu
        # (tanpa ini langit tetap jingga senja permanen saat malam)
        world = bpy.context.scene.world
        if world and world.use_nodes:
            bg = world.node_tree.nodes.get("World_BG")
            if bg:
                tahap_sky = [
                    (1,   (0.55, 0.70, 0.95, 1.0), 1.00),   # siang biru
                    (110, (0.85, 0.42, 0.25, 1.0), 0.75),   # senja jingga
                    (170, (0.02, 0.04, 0.09, 1.0), 0.20),   # malam gelap
                    (total_frames, (0.02, 0.04, 0.09, 1.0), 0.20),
                ]
                for f, col_sky, strength_sky in tahap_sky:
                    bg.inputs["Color"].default_value = col_sky
                    bg.inputs["Strength"].default_value = strength_sky
                    bg.inputs["Color"].keyframe_insert("default_value", frame=f)
                    bg.inputs["Strength"].keyframe_insert("default_value", frame=f)

        for obj in bpy.data.objects:
            if obj.type == "LIGHT" and obj.name.startswith("Spot_PJU"):
                obj.data.energy = 0.0
                obj.data.keyframe_insert(data_path="energy", frame=1)
                obj.data.energy = 0.0
                obj.data.keyframe_insert(data_path="energy", frame=85)
                obj.data.energy = 900.0
                obj.data.keyframe_insert(data_path="energy", frame=130)
                obj.data.energy = 900.0
                obj.data.keyframe_insert(data_path="energy", frame=total_frames)


# --------------------------------------------------------------------------
# 6. CameraRigManager & SplinePathBuilder
# --------------------------------------------------------------------------
class CameraRigManager:
    @classmethod
    def buat_kurva_drone_elips(cls, pusat_xy, radius_x, radius_y, ketinggian_z, koleksi_cam, total_frames=240):
        cx, cy = pusat_xy
        curve_data = bpy.data.curves.new(name="Spline_DroneTour", type="CURVE")
        curve_data.dimensions = "3D"
        curve_data.use_path = True
        curve_data.path_duration = total_frames

        spline = curve_data.splines.new(type="BEZIER")
        jml_titik = 8
        spline.bezier_points.add(jml_titik - 1)

        for i in range(jml_titik):
            theta = (2.0 * math.pi * i) / jml_titik
            px = cx + radius_x * math.cos(theta)
            py = cy + radius_y * math.sin(theta)
            pz = ketinggian_z + 2.5 * math.sin(theta * 2.0)
            bp = spline.bezier_points[i]
            bp.co = (px, py, pz)
            bp.handle_left_type = "AUTO"
            bp.handle_right_type = "AUTO"

        spline.use_cyclic_u = True

        curve_obj = bpy.data.objects.new(name="Spline_DroneTour", object_data=curve_data)
        bpy.context.scene.collection.objects.link(curve_obj)
        SceneManager.pindahkan_ke_koleksi(curve_obj, koleksi_cam)

        curve_data.eval_time = 0.0
        curve_data.keyframe_insert(data_path="eval_time", frame=1)
        curve_data.eval_time = float(total_frames)
        curve_data.keyframe_insert(data_path="eval_time", frame=total_frames)
        KeyframeAnimator.set_interpolasi_fcurve(curve_data, mode="LINEAR")
        return curve_obj

    @classmethod
    def bangun_semua_kamera(cls, ukuran_kawasan, koleksi_cam, mobil_utama=None, total_frames=240):
        wx, wy = ukuran_kawasan
        cx, cy = wx / 2.0, wy / 2.0

        target_focus = bpy.data.objects.new("Target_PlasaFocus", None)
        target_focus.empty_display_type = "SPHERE"
        target_focus.empty_display_size = 0.8
        bpy.context.scene.collection.objects.link(target_focus)
        Transform3DEngine.terapkan_matriks(target_focus, lokasi=(cx, cy + 2.0, 2.5))
        SceneManager.pindahkan_ke_koleksi(target_focus, koleksi_cam)

        # 1. Cam_Drone_Orbit
        spline_drone = cls.buat_kurva_drone_elips(
            pusat_xy=(cx, cy),
            radius_x=wx * 0.44,
            radius_y=wy * 0.46,
            ketinggian_z=14.5,
            koleksi_cam=koleksi_cam,
            total_frames=total_frames,
        )
        cam1_data = bpy.data.cameras.new("Cam_Drone_Orbit")
        cam1_data.type = "PERSP"
        cam1_data.lens = 24.0
        cam1_data.clip_end = 500.0
        cam1 = bpy.data.objects.new("Cam_Drone_Orbit", cam1_data)
        cam1.location = (0.0, 0.0, 0.0)
        bpy.context.scene.collection.objects.link(cam1)
        SceneManager.pindahkan_ke_koleksi(cam1, koleksi_cam)

        c_follow = cam1.constraints.new(type="FOLLOW_PATH")
        c_follow.target = spline_drone
        c_track = cam1.constraints.new(type="TRACK_TO")
        c_track.target = target_focus
        c_track.track_axis = "TRACK_NEGATIVE_Z"
        c_track.up_axis = "UP_Y"

        # 2. Cam_Street_EyeLevel
        cam2_data = bpy.data.cameras.new("Cam_Street_EyeLevel")
        cam2_data.type = "PERSP"
        cam2_data.lens = 35.0
        cam2_data.dof.use_dof = True
        cam2_data.dof.focus_object = target_focus
        cam2_data.dof.aperture_fstop = 2.0
        cam2 = bpy.data.objects.new("Cam_Street_EyeLevel", cam2_data)
        bpy.context.scene.collection.objects.link(cam2)
        Transform3DEngine.terapkan_matriks(cam2, lokasi=(6.0, cy - 3.2, 1.75))
        # Aim kamera tepat ke Target_PlasaFocus agar bidang fokus DOF jatuh di subjek
        arah_street = (Vector((cx, cy + 2.0, 2.5)) - Vector((6.0, cy - 3.2, 1.75))).normalized()
        cam2.rotation_euler = arah_street.to_track_quat("-Z", "Y").to_euler()
        SceneManager.pindahkan_ke_koleksi(cam2, koleksi_cam)

        # 3. Cam_Isometric_Ortho
        cam3_data = bpy.data.cameras.new("Cam_Isometric_Ortho")
        cam3_data.type = "ORTHO"
        cam3_data.ortho_scale = max(wx, wy) * 0.95
        cam3 = bpy.data.objects.new("Cam_Isometric_Ortho", cam3_data)
        bpy.context.scene.collection.objects.link(cam3)
        Transform3DEngine.terapkan_matriks(
            cam3,
            lokasi=(cx - 28.0, cy - 28.0, 32.0),
            rotasi_euler=(math.radians(54.736), 0.0, math.radians(-45.0)),
        )
        SceneManager.pindahkan_ke_koleksi(cam3, koleksi_cam)

        # 4. Cam_Car_Dashcam
        cam4_data = bpy.data.cameras.new("Cam_Car_Dashcam")
        cam4_data.type = "PERSP"
        cam4_data.lens = 22.0
        cam4 = bpy.data.objects.new("Cam_Car_Dashcam", cam4_data)
        bpy.context.scene.collection.objects.link(cam4)
        # Dashcam memandang ke DEPAN mobil (sumbu +X lokal) sedikit menunduk
        arah_dash = Vector((1.0, 0.0, -0.10)).normalized()
        Transform3DEngine.terapkan_matriks(
            cam4,
            lokasi=(1.0, 0.0, 1.32),
            rotasi_euler=arah_dash.to_track_quat("-Z", "Y").to_euler(),
            parent=mobil_utama,
        )
        SceneManager.pindahkan_ke_koleksi(cam4, koleksi_cam)

        bpy.context.scene.camera = cam1
        return cam1


# --------------------------------------------------------------------------
# 7. ExportPipelineManager: Render Video MP4 (FFmpeg H.264) & Web 3D (.GLB)
# --------------------------------------------------------------------------
class ExportPipelineManager:
    """
    MATERI 4 - RENDERING PIPELINE & WEB 3D EXPORT:
      1. resolve_output_dir() : Menentukan folder simpan aman (folder .blend
                                jika sudah tersimpan, atau Desktop/Temp jika belum).
      2. render_animasi_mp4() : Merender timeline 1..240 ke MP4 (H.264 + EEVEE).
      3. export_web_glb()     : Mengekspor seluruh scene (Mesh, Hierarki, Animasi,
                                Kamera & Lampu) ke format biner glTF 2.0 (.glb).
    """

    @staticmethod
    def resolve_output_dir(custom_dir=""):
        if custom_dir and custom_dir.strip():
            abs_dir = bpy.path.abspath(custom_dir.strip())
            os.makedirs(abs_dir, exist_ok=True)
            return abs_dir
        if bpy.data.filepath:
            return os.path.dirname(bpy.data.filepath)
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        if os.path.isdir(desktop):
            return desktop
        return tempfile.gettempdir()

    @classmethod
    def render_animasi_mp4(cls, output_dir="", resolusi="720P"):
        scene = bpy.context.scene
        target_dir = cls.resolve_output_dir(output_dir)
        mp4_path = os.path.join(target_dir, "CityTour_Modul4.mp4")

        # Resolusi video
        if resolusi == "1080P":
            scene.render.resolution_x = 1920
            scene.render.resolution_y = 1080
        else:
            scene.render.resolution_x = 1280
            scene.render.resolution_y = 720
        scene.render.resolution_percentage = 100

        # Konfigurasi FFmpeg MPEG-4 / H.264 di Blender 4.3
        scene.render.image_settings.file_format = "FFMPEG"
        scene.render.ffmpeg.format = "MPEG4"
        scene.render.ffmpeg.codec = "H264"
        scene.render.ffmpeg.constant_rate_factor = "HIGH"
        scene.render.ffmpeg.ffmpeg_preset = "GOOD"
        scene.render.filepath = mp4_path

        # Jalankan render animasi dengan jendela progres live
        bpy.ops.render.render("INVOKE_DEFAULT", animation=True)
        return mp4_path

    @classmethod
    def export_web_glb(cls, output_dir="", sertakan_animasi=True):
        target_dir = cls.resolve_output_dir(output_dir)
        glb_path = os.path.join(target_dir, "KawasanMakro_Modul4.glb")

        # Pastikan mode OBJECT sebelum ekspor glTF
        if bpy.context.active_object and bpy.context.active_object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        try:
            bpy.ops.export_scene.gltf(
                filepath=glb_path,
                export_format="GLB",
                use_selection=False,
                export_yup=True,
                export_cameras=True,
                export_lights=True,
                export_animations=sertakan_animasi,
            )
        except TypeError:
            # Fallback jika versi add-on glTF memiliki perbedaan parameter minor
            bpy.ops.export_scene.gltf(
                filepath=glb_path,
                export_format="GLB",
                export_animations=sertakan_animasi,
            )
        return glb_path


