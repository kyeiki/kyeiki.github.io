# -*- coding: utf-8 -*-
# Dibangun otomatis oleh tools/extract_kgworkshop.py — salinan VERBATIM
# dari monolith terverifikasi (jangan edit manual; regenerate ulang).
# Konfigurasi kawasan makro Modul 3 (sumber: modul3.py BAGIAN 1-2)
# + palet material Modul 4 (CONFIG_MATERIAL_MODUL4, sumber: modul4).

# ==============================================================================
# BAGIAN 1: KONFIGURASI KAWASAN MAKRO & DENAH GEDUNG 2 LANTAI
# ==============================================================================
SKALA_MAKRO_METER = 1.0          # 1 karakter di peta makro = 1.0 meter
TINGGI_PER_LANTAI = 3.2          # Tinggi per lantai = 3.2m (2 lantai = 6.4m)
TEBAL_DINDING     = 0.18
TEBAL_SLAB_LANTAI = 0.22

# Peta Kawasan Makro (Masterplan 3 Gedung + Jalan Utama + Taman & Plasa)
# Legenda Karakter:
#   '=' : Jalan Raya Aspal       '#' : Marka Putih Jalan
#   '.' : Trotoar Pejalan Kaki   '~' : Taman Rumput Hijau
#   'T' : Pohon Taman            'L' : Tiang Lampu Jalan (Spot Light)
#   'B' : Bangku Taman           'W' : Kolam Air Mancur Plasa
#   'C' : Mobil LEGO di Jalan
PETA_MAKRO_ASCII = r"""
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~  T       +-------------------+      T      +-----------------+ ~~
~~          |                   |             |                 | ~~
~~     T    |     GEDUNG A      |      W      |    GEDUNG B     | ~~
~~          |    (2 LANTAI)     |     WWW     |   (2 LANTAI)    | ~~
~~  B       |   KANTOR UTAMA    |      W      |   PUSAT RISET   | ~~
~~          |                   |             |                 | ~~
~~          +-------------------+      B      +-----------------+ ~~
....................................................................
..  L             L                   L                 L         ..
====================================================================
====  C  =============  #  =============  #  ========  C  ==========
====     =============     =============     =======================
====================================================================
..  L             L                   L                 L         ..
....................................................................
~~  T       +-----------------------------------------+     T     ~~
~~          |                                         |           ~~
~~  B       |                GEDUNG C                 |     B     ~~
~~          |         (2 LANTAI - CONVENTION)         |           ~~
~~     T    |                                         |  T     T  ~~
~~          +-----------------------------------------+           ~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"""

# Denah Interior Modular yang dipakai untuk mengekstrusi tiap lantai gedung
DENAH_GEDUNG_MODULAR_ASCII = r"""
+-----------+---------------+-----------+
|   RUANG   |    KORIDOR    |   RUANG   |
|  RAPAT 1  |     UTAMA     |  RAPAT 2  |
+-----------+-------+-------+-----------+
|                   |                   |
|    WORKSTATION    |    WORKSTATION    |
|       BARAT       |       TIMUR       |
+-------------------+-------------------+
"""


# ==============================================================================
# BAGIAN 2: PALET MATERIAL & SHADER (TERMASUK EMISSION & ENVIRONMENT)
# ==============================================================================
CONFIG_MATERIAL_MODUL3 = {
    # Material Gedung
    "dinding_eksterior_a": {
        "rgba": [0.88, 0.85, 0.78, 1.0], "roughness": 0.75,
        "tex_type": "BRICK", "color2": [0.72, 0.66, 0.58, 1.0], "uv_scale": [5.0, 5.0, 5.0], "bump": 0.20
    },
    "dinding_eksterior_b": {
        "rgba": [0.74, 0.80, 0.86, 1.0], "roughness": 0.55, "metallic": 0.25,
        "tex_type": "BRICK", "color2": [0.58, 0.65, 0.72, 1.0], "uv_scale": [4.0, 4.0, 4.0], "bump": 0.15
    },
    "dinding_eksterior_c": {
        "rgba": [0.86, 0.78, 0.72, 1.0], "roughness": 0.70,
        "tex_type": "BRICK", "color2": [0.68, 0.56, 0.48, 1.0], "uv_scale": [6.0, 6.0, 6.0], "bump": 0.22
    },
    "dinding_interior": {
        "rgba": [0.92, 0.92, 0.94, 1.0], "roughness": 0.70, "tex_type": "NOISE", "uv_scale": [8.0, 8.0, 8.0], "bump": 0.05
    },
    "slab_beton": {
        "rgba": [0.55, 0.57, 0.60, 1.0], "roughness": 0.80, "tex_type": "NOISE", "uv_scale": [6.0, 6.0, 6.0], "bump": 0.12
    },
    "lantai_interior": {
        "rgba": [0.84, 0.80, 0.72, 1.0], "roughness": 0.35,
        "tex_type": "CHECKER", "color2": [0.70, 0.65, 0.56, 1.0], "uv_scale": [10.0, 10.0, 1.0], "bump": 0.04
    },
    "kaca_fasad": {
        "rgba": [0.55, 0.80, 0.95, 1.0], "roughness": 0.08, "metallic": 0.15,
        "emission": [0.95, 0.85, 0.55, 1.0], "emission_strength": 0.35
    },
    "kusen_hitam": {"rgba": [0.15, 0.17, 0.20, 1.0], "roughness": 0.30, "metallic": 0.75},
    # Material Jalan, Taman & Lingkungan
    "aspal_jalan": {
        "rgba": [0.16, 0.17, 0.19, 1.0], "roughness": 0.88,
        "tex_type": "NOISE", "uv_scale": [25.0, 25.0, 1.0], "bump": 0.30
    },
    "marka_jalan": {
        "rgba": [0.96, 0.96, 0.92, 1.0], "roughness": 0.40,
        "emission": [0.95, 0.95, 0.85, 1.0], "emission_strength": 0.25
    },
    "trotoar_paving": {
        "rgba": [0.68, 0.66, 0.62, 1.0], "roughness": 0.75,
        "tex_type": "CHECKER", "color2": [0.56, 0.54, 0.50, 1.0], "uv_scale": [20.0, 20.0, 1.0], "bump": 0.15
    },
    "rumput_taman": {
        "rgba": [0.20, 0.52, 0.22, 1.0], "roughness": 0.90,
        "tex_type": "NOISE", "uv_scale": [18.0, 18.0, 1.0], "bump": 0.25
    },
    "batang_pohon": {
        "rgba": [0.38, 0.24, 0.12, 1.0], "roughness": 0.85,
        "tex_type": "WOOD", "color2": [0.24, 0.14, 0.06, 1.0], "uv_scale": [5.0, 5.0, 5.0], "bump": 0.20
    },
    "daun_pohon": {
        "rgba": [0.16, 0.58, 0.20, 1.0], "roughness": 0.75,
        "tex_type": "NOISE", "uv_scale": [8.0, 8.0, 8.0], "bump": 0.18
    },
    "air_kolam": {
        "rgba": [0.18, 0.62, 0.82, 1.0], "roughness": 0.05, "metallic": 0.10,
        "tex_type": "WOOD", "color2": [0.35, 0.80, 0.95, 1.0], "uv_scale": [8.0, 8.0, 1.0], "bump": 0.08
    },
    "tiang_lampu": {"rgba": [0.22, 0.25, 0.28, 1.0], "roughness": 0.35, "metallic": 0.80},
    "bohlam_lampu": {
        "rgba": [1.0, 0.92, 0.72, 1.0], "roughness": 0.10,
        "emission": [1.0, 0.88, 0.60, 1.0], "emission_strength": 6.0
    },
    "kayu_bangku": {
        "rgba": [0.62, 0.38, 0.18, 1.0], "roughness": 0.55,
        "tex_type": "WOOD", "color2": [0.42, 0.24, 0.10, 1.0], "uv_scale": [4.0, 4.0, 4.0], "bump": 0.10
    },
    "mobil_merah":  {"rgba": [0.85, 0.14, 0.14, 1.0], "roughness": 0.20, "metallic": 0.30},
    "mobil_biru":   {"rgba": [0.14, 0.42, 0.86, 1.0], "roughness": 0.20, "metallic": 0.30},
    "roda_hitam":   {"rgba": [0.12, 0.12, 0.14, 1.0], "roughness": 0.85},
}


CONFIG_MATERIAL_MODUL4 = {
    "dinding_eksterior_a": {
        "rgba": [0.88, 0.85, 0.78, 1.0], "roughness": 0.75,
        "tex_type": "BRICK", "color2": [0.72, 0.66, 0.58, 1.0], "uv_scale": [5.0, 5.0, 5.0], "bump": 0.20
    },
    "dinding_eksterior_b": {
        "rgba": [0.74, 0.80, 0.86, 1.0], "roughness": 0.55, "metallic": 0.25,
        "tex_type": "BRICK", "color2": [0.58, 0.65, 0.72, 1.0], "uv_scale": [4.0, 4.0, 4.0], "bump": 0.15
    },
    "dinding_eksterior_c": {
        "rgba": [0.86, 0.78, 0.72, 1.0], "roughness": 0.70,
        "tex_type": "BRICK", "color2": [0.68, 0.56, 0.48, 1.0], "uv_scale": [6.0, 6.0, 6.0], "bump": 0.22
    },
    "dinding_interior": {
        "rgba": [0.92, 0.92, 0.94, 1.0], "roughness": 0.70, "tex_type": "NOISE", "uv_scale": [8.0, 8.0, 8.0], "bump": 0.05
    },
    "slab_beton": {
        "rgba": [0.55, 0.57, 0.60, 1.0], "roughness": 0.80, "tex_type": "NOISE", "uv_scale": [6.0, 6.0, 6.0], "bump": 0.12
    },
    "lantai_interior": {
        "rgba": [0.84, 0.80, 0.72, 1.0], "roughness": 0.35,
        "tex_type": "CHECKER", "color2": [0.70, 0.65, 0.56, 1.0], "uv_scale": [10.0, 10.0, 1.0], "bump": 0.04
    },
    "kaca_fasad": {
        "rgba": [0.55, 0.80, 0.95, 1.0], "roughness": 0.08, "metallic": 0.15,
        "emission": [0.95, 0.85, 0.55, 1.0], "emission_strength": 1.20
    },
    "kaca_lift": {
        "rgba": [0.40, 0.85, 0.98, 1.0], "roughness": 0.05, "metallic": 0.20,
        "emission": [0.25, 0.75, 1.0, 1.0], "emission_strength": 1.80
    },
    "kusen_hitam": {"rgba": [0.15, 0.17, 0.20, 1.0], "roughness": 0.30, "metallic": 0.75},
    "aspal_jalan": {
        "rgba": [0.16, 0.17, 0.19, 1.0], "roughness": 0.88,
        "tex_type": "NOISE", "uv_scale": [25.0, 25.0, 1.0], "bump": 0.30
    },
    "marka_jalan": {
        "rgba": [0.96, 0.96, 0.92, 1.0], "roughness": 0.40,
        "emission": [0.95, 0.95, 0.85, 1.0], "emission_strength": 0.40
    },
    "trotoar_paving": {
        "rgba": [0.68, 0.66, 0.62, 1.0], "roughness": 0.75,
        "tex_type": "CHECKER", "color2": [0.56, 0.54, 0.50, 1.0], "uv_scale": [20.0, 20.0, 1.0], "bump": 0.15
    },
    "rumput_taman": {
        "rgba": [0.20, 0.52, 0.22, 1.0], "roughness": 0.90,
        "tex_type": "NOISE", "uv_scale": [18.0, 18.0, 1.0], "bump": 0.25
    },
    "batang_pohon": {
        "rgba": [0.38, 0.24, 0.12, 1.0], "roughness": 0.85,
        "tex_type": "WOOD", "color2": [0.24, 0.14, 0.06, 1.0], "uv_scale": [5.0, 5.0, 5.0], "bump": 0.20
    },
    "daun_pohon": {
        "rgba": [0.16, 0.58, 0.20, 1.0], "roughness": 0.75,
        "tex_type": "NOISE", "uv_scale": [8.0, 8.0, 8.0], "bump": 0.18
    },
    "air_kolam": {
        "rgba": [0.18, 0.62, 0.82, 1.0], "roughness": 0.05, "metallic": 0.10,
        "tex_type": "WOOD", "color2": [0.35, 0.80, 0.95, 1.0], "uv_scale": [8.0, 8.0, 1.0], "bump": 0.08
    },
    "tiang_lampu": {"rgba": [0.22, 0.25, 0.28, 1.0], "roughness": 0.35, "metallic": 0.80},
    "bohlam_lampu": {
        "rgba": [1.0, 0.92, 0.72, 1.0], "roughness": 0.10,
        "emission": [1.0, 0.88, 0.60, 1.0], "emission_strength": 8.0
    },
    "lampu_mobil": {
        "rgba": [1.0, 0.98, 0.85, 1.0], "roughness": 0.10,
        "emission": [1.0, 0.96, 0.80, 1.0], "emission_strength": 10.0
    },
    "kayu_bangku": {
        "rgba": [0.62, 0.38, 0.18, 1.0], "roughness": 0.55,
        "tex_type": "WOOD", "color2": [0.42, 0.24, 0.10, 1.0], "uv_scale": [4.0, 4.0, 4.0], "bump": 0.10
    },
    "mobil_merah":  {"rgba": [0.85, 0.14, 0.14, 1.0], "roughness": 0.20, "metallic": 0.30},
    "mobil_biru":   {"rgba": [0.14, 0.42, 0.86, 1.0], "roughness": 0.20, "metallic": 0.30},
    "roda_hitam":   {"rgba": [0.12, 0.12, 0.14, 1.0], "roughness": 0.85},
}


